"""Native FP4 scorer and complete backend-method oracle on eight idle SM121s."""
import ast
from datetime import timedelta
import gc,hashlib,json,logging,os
from pathlib import Path
import sys
from types import SimpleNamespace,MethodType
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO)
torch.set_num_threads(1);torch.cuda.set_device(0)
rank=int(os.environ['RANK']);OUT=Path('/state');SOURCE=Path('/tests/source')
sys.path.insert(0,'/candidate/production/python/sglang/srt/layers/attention/dsv4')
from spark_prefill_dense import NativePrefillTPSplit,partition,candidate_block_ids,candidate_mask
from sglang.kernels.ops.attention.dsv4 import topk_transform_ragged_v2
from sglang.kernels.ops.attention.dsv4.fp4_indexer import quantize_fp4_indexer_tensor

def function(path,name,namespace):
 tree=ast.parse(path.read_text());matches=[n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name]
 assert len(matches)==1,(path,name,len(matches))
 node=matches[0];node.decorator_list=[]
 body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node]
 exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),str(path),'exec'),namespace)
 return namespace[name]

ns=dict(torch=torch,F=F,_TORCH_INDEXER_SCORE_BUDGET_BYTES=1<<30,ceil_align=lambda n,d:((n+d-1)//d)*d,_as_int_list=lambda x:list(x),topk_transform_ragged_v2=topk_transform_ragged_v2)
selector=function(SOURCE/'indexer.py','select_candidate_blocks',ns)
mask_topk=function(SOURCE/'backend.py','_mask_topk_scores',ns)
dense=function(SOURCE/'backend.py','_dense_fp4_mqa_logits',ns)
publish=function(SOURCE/'backend.py','_publish_or_consume_candidates',ns)
base_method=function(SOURCE/'backend.py','_low_ratio_index_topk_dense',ns)
cns=dict(ns)
candidate_method=function(Path('/candidate/production/python/sglang/srt/layers/attention/deepseek_v4_backend.py'),'_low_ratio_index_topk_dense',cns)
report=dict(status='RUNNING',rank=rank,cases=[],compact_masks=[],torch=torch.__version__)
def save():(OUT/'component-results.json').write_text(json.dumps(report,indent=2)+'\n')
def exact(a,b,tag):
 assert a.shape==b.shape and a.dtype==b.dtype,(tag,a.shape,b.shape,a.dtype,b.dtype)
 assert torch.equal(a,b),(tag,int((a!=b).sum()))
def digest(a):return hashlib.sha256(a.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()

for width in [1,7,8,9,63,65,193,2051]:
 for blocks in [1,3,2048]:
  torch.manual_seed(93920+width+blocks)
  scores=torch.randn((13,width),device='cuda')
  lens=torch.tensor([0,1,2,7,8,9,width//3,width//2,width-1,width,width,0,width],device='cuda').clamp_max(width)[:,None]
  scores[0].zero_();scores[1].fill_(-torch.inf);scores[2].zero_();scores[3,::11]=torch.inf;scores[4,::13]=torch.nan
  scores=scores.masked_fill(torch.arange(width,device='cuda')>=lens,-torch.inf)
  ids=candidate_block_ids(scores,lens,blocks,8)
  exact(selector(scores,lens,blocks,8),candidate_mask(ids,width,8),'compact')
  report['compact_masks'].append(dict(width=width,blocks=blocks,status='PASS'))
save()

torch.distributed.init_process_group('nccl',init_method='tcp://192.168.100.11:29871',rank=rank,world_size=8,timeout=timedelta(seconds=300))
from sglang.srt.distributed.parallel_state import GroupCoordinator
coordinator=GroupCoordinator([list(range(8))],local_rank=0,torch_distributed_backend='nccl',use_pynccl=True,use_pymscclpp=False,use_custom_allreduce=False,use_torch_symm_mem_all_reduce=False,use_hpu_communicator=False,use_xpu_communicator=False,use_npu_communicator=False,group_name='native_prefill_component',gloo_timeout=timedelta(seconds=300))
from sglang.srt.runtime_context import get_flags
from sglang.srt.distributed.device_communicators.pynccl_allocator import is_symmetric_memory_enabled
assert not get_flags().dp.enabled and not is_symmetric_memory_enabled()
class Group:
 world_size=8;rank_in_group=rank
 def __init__(self):self.calls=[]
 def all_gather(self,value,dim=0):
  result=coordinator.all_gather(value,dim=dim);self.calls.append(dict(input=list(value.shape),output=list(result.shape),dtype=str(value.dtype)));return result
 def all_gather_object(self,value):return coordinator.all_gather_object(value)
group=Group();parallel=SimpleNamespace(attn_tp_group=group,attn_cp_size=1,attn_dp_size=1,attn_dcp_size=1)
engine=NativePrefillTPSplit.from_parallel(parallel,is_draft=False);assert engine.enabled
markers=torch.arange(119,device='cuda',dtype=torch.int32).view(17,7)+rank*10000
marker_all=group.all_gather(markers)
exact(marker_all,torch.cat([torch.arange(119,device='cuda',dtype=torch.int32).view(17,7)+r*10000 for r in range(8)]),'all-rank-markers')
for key in ['SPARK_PREFILL_TP_SPLIT','SPARK_PREFILL_TP_MIN_CONTEXT','SPARK_PREFILL_TP_MIN_ROWS']:
 previous=os.environ[key]
 if rank==7:os.environ[key]='0' if key.endswith('SPLIT') else str(int(previous)+1)
 try:NativePrefillTPSplit.from_parallel(parallel,is_draft=False)
 except RuntimeError as error:assert 'Inconsistent' in str(error)
 else:raise AssertionError('setting mismatch accepted')
 os.environ[key]=previous
os.environ['SPARK_PREFILL_TP_SPLIT']='0';assert not NativePrefillTPSplit.from_parallel(parallel,is_draft=False).enabled
os.environ['SPARK_PREFILL_TP_SPLIT']='1'
assert not NativePrefillTPSplit.from_parallel(parallel,is_draft=True).enabled
parallel.attn_cp_size=2;assert not NativePrefillTPSplit.from_parallel(parallel,is_draft=False).enabled;parallel.attn_cp_size=1
assert not engine.eligible(2048,32767,prefill=True,device=torch.device('cuda'))
assert not engine.eligible(1023,131072,prefill=True,device=torch.device('cuda'))
assert not engine.eligible(2048,131072,prefill=False,device=torch.device('cuda'))
assert not engine.eligible(2048,131072,prefill=True,device=torch.device('cpu'))
g=torch.cuda.CUDAGraph();dummy=torch.zeros(1,device='cuda');stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
with torch.cuda.stream(stream):
 for _ in range(3):dummy.add_(1)
stream.synchronize()
with torch.cuda.graph(g,stream=stream):
 assert not engine.eligible(2048,131072,prefill=True,device=dummy.device);dummy.add_(1)
g.replay();torch.cuda.synchronize();del g,dummy,stream
report['dispatch_gates']='PASS: disabled, mismatched settings, draft, CP2, short rows/context, CPU, nonprefill, real CUDA capture'
report['group']=dict(type='Actual GroupCoordinator eager all_gather',pynccl_available=coordinator.pynccl_comm.available,pynccl_disabled=coordinator.pynccl_comm.disabled,dp_enabled=get_flags().dp.enabled,symmetric_memory_enabled=is_symmetric_memory_enabled(),marker_sha256=digest(marker_all))
save()

class ShapeGate:
 def __init__(self,enabled):self.enabled=enabled
 def eligible(self,*args,**kwargs):return self.enabled
 def select(self,*args,**kwargs):return engine.select(*args,**kwargs)

def fixture(counts,widths,ratio,blocks,zero):
 torch.manual_seed(32188+sum(counts)+sum(widths)+ratio+blocks)
 total=sum(counts);positions=[]
 for count,width in zip(counts,widths):
  p=(torch.arange(count,device='cuda')*ratio+(width-count)*ratio+ratio-1).clamp_min(0)
  if width==0:p.zero_()
  elif count and width<4096:
   p[:min(5,count)]=torch.tensor([0,ratio-1,2*ratio-1,7*ratio-1,8*ratio-1],device='cuda')[:min(5,count)].clamp_max(width*ratio-1)
  positions.append(p)
 pos=torch.cat(positions).long()
 if ratio==1:
  # ratio-1 position zero has one visible token; zero-width requests use no rows.
  assert all(w or not c for c,w in zip(counts,widths))
 q=torch.randn((total,32,128),device='cuda',dtype=torch.bfloat16)*.25
 w=torch.randn((total,32),device='cuda',dtype=torch.bfloat16)*.125
 k=torch.randn((sum(widths),128),device='cuda',dtype=torch.bfloat16)*.25
 if zero:q.zero_();w.zero_()
 kp,ksf=quantize_fp4_indexer_tensor(k,rne=True)
 maxcols=max(1,max(widths)*ratio)
 columns=torch.arange(maxcols,device='cuda')
 table=torch.stack([((columns//ratio)*3+7+r*(max(widths)*4+29))*ratio for r in range(6)])
 reqids=torch.tensor([3,1,4][:len(counts)],dtype=torch.int32,device='cuda')
 expected=torch.cat([table[int(r),torch.arange(width,device='cuda')*ratio].long()//ratio for r,width in zip(reqids.cpu(),widths)])
 def get_k(layer,slots):exact(slots,expected,'physical-key-slot-order');return kp,ksf
 indexer=SimpleNamespace(index_topk=512,is_candidate_source=True,uses_candidates=False,candidate_topk_blocks=blocks,candidate_block_size=8,
                         queries=lambda *args:q,head_weights=lambda *args:w)
 layer=SimpleNamespace(compress_ratio=ratio,indexer=indexer,layer_id=7,freqs_cis=torch.zeros((max(int(pos.max())+1,1),1),device='cuda'))
 fb=SimpleNamespace(seq_lens_cpu=[v*ratio if v else (1 if count else 0) for count,v in zip(counts,widths)],req_pool_indices=reqids,forward_mode=SimpleNamespace(is_extend_without_speculative=lambda:True))
 return dict(total=total,layer=layer,fb=fb,pos=pos,counts=counts,widths=widths,ratio=ratio,q=q,w=w,k=k,kp=kp,ksf=ksf,table=table,get_k=get_k)

def run_method(method,f,source,consume,split,uses_candidates=None):
 total=f['total'];idx=f['layer'].indexer;idx.is_candidate_source=source;idx.uses_candidates=(not source) if uses_candidates is None else uses_candidates
 page=torch.empty((total,512),dtype=torch.int32,device='cuda');raw=torch.empty_like(page)
 core=SimpleNamespace(sparse_page_indices=lambda r:page,sparse_raw_indices=lambda r:raw)
 backend=SimpleNamespace(token_to_kv_pool=SimpleNamespace(get_low_ratio_index_k_fp4=f['get_k']),forward_metadata=SimpleNamespace(core_metadata=core),req_to_token=f['table'],candidate_masks=None if consume is None else [x.clone() for x in consume],native_prefill_tp=ShapeGate(split))
 backend._publish_or_consume_candidates=MethodType(publish,backend)
 method(backend,f['layer'],None,None,f['pos'],f['fb'],torch.tensor(f['counts'],device='cuda',dtype=torch.int32),f['counts'])
 return page,raw,backend.candidate_masks

def tied_selection_check(value,f,uses_candidates,consume,original_logits):
 raw,page=value[1],value[0];ratio=f['ratio'];lens=((f['pos']+1)//ratio).to(torch.int32)
 reachable=torch.arange(original_logits.shape[1],device='cuda')[None,:]<lens[:,None]
 actual=original_logits[reachable]
 exact(actual,torch.zeros_like(actual),'deliberately-all-zero-valid-logits')
 allowed=reachable.clone()
 if uses_candidates:
  offset=0
  for width,count,mask in zip(f['widths'],f['counts'],consume):
   if width and count:allowed[offset:offset+count,:width]&=mask
   offset+=count
 keep=raw>=0;cols=raw.long().clamp_min(0)
 assert ((raw<lens[:,None])|~keep).all(),'tied selection outside causal window'
 assert (allowed.gather(1,cols)|~keep).all(),'tied selection outside candidates'
 exact(keep.sum(dim=1),allowed.sum(dim=1).clamp_max(512),'tied optimal selection count')
 normalized=raw.masked_fill(~keep,torch.iinfo(torch.int32).max).sort(dim=1).values
 assert not ((normalized[:,1:]==normalized[:,:-1])&(normalized[:,1:]!=torch.iinfo(torch.int32).max)).any(),'duplicate tied selection'
 offset=0
 for request,count in enumerate(f['counts']):
  local_raw=raw[offset:offset+count];local_keep=local_raw>=0
  expected_page=torch.where(local_keep,f['table'][f['fb'].req_pool_indices[request].long(),local_raw.long().clamp_min(0)*ratio]//ratio,-1).to(torch.int32)
  exact(page[offset:offset+count],expected_page,'tied exact physical-page mapping')
  offset+=count
 # Every permitted score is exactly zero, so count + membership + uniqueness
 # prove the same optimal score multiset without inventing a tie-break order.

def one(counts,widths,ratio,blocks=2048,zero=False,split=True):
 f=fixture(counts,widths,ratio,blocks,zero);reference={};score_checks=[]
 def oracle(*args):
  result=dense(*args);reference['logits']=result.clone();return result
 def partition_scorer(*args):
  result=dense(*args)
  q=args[0][0];start=q.storage_offset()//q.stride(0);length=(args[4]-args[3]).long()
  valid=torch.arange(result.shape[1],device='cuda')[None,:]<length[:,None]
  expected=reference['logits'][start:start+result.shape[0]]
  exact(result[valid],expected[valid],'native-FP4-valid-logits')
  score_checks.append(dict(start=start,rows=result.shape[0],valid_values=int(valid.sum())))
  return result
 ns['_dense_fp4_mqa_logits']=oracle;cns['_dense_fp4_mqa_logits']=partition_scorer if split else dense
 source_masks=None
 for source,uses_candidates in [(True,False),(False,True),(False,False)]:
  a=run_method(base_method,f,source,source_masks if uses_candidates else None,False,uses_candidates)
  a2=run_method(base_method,f,source,source_masks if uses_candidates else None,False,uses_candidates)
  allow_ties=zero and max(widths)>512
  if not allow_ties:exact(a[0],a2[0],'repeat-page');exact(a[1],a2[1],'repeat-raw')
  if source:
   for x,y in zip(a[2],a2[2]):exact(x,y,'repeat-mask')
  before=len(group.calls)
  b=run_method(candidate_method,f,source,source_masks if uses_candidates else None,split,uses_candidates)
  assert len(group.calls)-before==int(split)
  if allow_ties:
   for value in [a,a2,b]:tied_selection_check(value,f,uses_candidates,source_masks,reference['logits'])
   report.setdefault('tie_observations',[]).append(dict(counts=counts,widths=widths,source=source,uses_candidates=uses_candidates,baseline_changed_indices=int((a[1]!=a2[1]).sum()),candidate_changed_indices=int((a[1]!=b[1]).sum()),score_multiset='EXACT',membership_unique_count_and_page_mapping='PASS'))
  else:exact(a[0],b[0],'candidate-page');exact(a[1],b[1],'candidate-raw')
  if source:
   for x,y in zip(a[2],b[2]):exact(x,y,'candidate-mask')
   source_masks=[x.clone() for x in a[2]]
  report['cases'].append(dict(counts=counts,widths=widths,ratio=ratio,blocks=blocks,zero=zero,source=source,uses_candidates=uses_candidates,split=split,
                              comparison='EXACT_TIED_SCORE_MULTISET_AND_VALID_SELECTION' if allow_ties else 'EXACT_RAW_PAGE_INDICES',raw_sha256=digest(b[1]),page_sha256=digest(b[0]),mask_sha256=[digest(x) for x in b[2]] if source else None))
  save();print(json.dumps(dict(rank=rank,counts=counts,widths=widths,ratio=ratio,source=source,uses_candidates=uses_candidates,split=split,status='PASS')),flush=True)
  del a,a2,b
 report.setdefault('score_checks',[]).extend(score_checks)
 del f,reference,source_masks;gc.collect();torch.cuda.empty_cache();torch.distributed.barrier()

for args in [
 ([8],[65],1,1,True,True),
 ([17],[2051],2,3,True,True),
 ([129,19],[193,65],2,3,False,True),
 ([129,0,17],[193,0,65],1,3,False,True),
 ([128,1],[193,0],2,3,False,True),
 ([1025],[32768],1,2048,False,True),
 ([2048],[65536],2,2048,False,True),
 ([2048],[131072],1,2048,False,True),
 ([1024,1024],[131072,65536],2,2048,False,True),
 ([2048],[299008],1,2048,False,True),
 ([2048],[149504],2,2048,False,True),
 ([2048],[997000],1,2048,False,True),
 ([2048],[498500],2,2048,False,True),
 ([2048],[32768],1,2048,True,True),
 ([31],[65],1,3,False,False),
]:one(*args)
report['status']='PASS';report['collective_calls']=group.calls;save()
torch.distributed.barrier();torch.distributed.destroy_process_group()
print('NATIVE_PREFILL_COMPONENT_PASS',rank,flush=True)
