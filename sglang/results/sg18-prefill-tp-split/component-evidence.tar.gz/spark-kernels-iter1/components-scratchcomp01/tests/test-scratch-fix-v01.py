"""Model-free production-wrapper regression: controlled poisoned allocation.

No serving process is modified. Run in a dedicated container on an idle GPU.
The old module's uint8 allocations are deliberately filled with 0xff, modeling
recycled allocator bytes; the corrected module must clear them on allocation.
"""
import hashlib,importlib.util,json,math,os,pathlib,types
import torch
import sglang.srt.runtime_context as runtime

out=pathlib.Path('/state');rank=int(os.environ['RANK']);torch.cuda.set_device(0)
assert torch.cuda.get_device_capability()==(12,1)
buffers={};runtime.get_resources=lambda:types.SimpleNamespace(buffers=buffers)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=module('scratch_old','/tests/source/flash_mla_sm120.py')
new=module('scratch_fixed','/candidate/production/python/sglang/kernels/ops/attention/flash_mla_sm120.py')
class Allocator:
 def __init__(self,fill):self.fill=fill;self.allocations=[]
 def __getattr__(self,key):return getattr(torch,key)
 def empty(self,*args,**kwargs):
  t=torch.empty(*args,**kwargs)
  if t.dtype==torch.uint8:t.fill_(self.fill);self.allocations.append(dict(kind='empty',shape=list(t.shape),fill=self.fill))
  return t
 def zeros(self,*args,**kwargs):
  t=torch.zeros(*args,**kwargs)
  if t.dtype==torch.uint8:self.allocations.append(dict(kind='zeros',shape=list(t.shape),fill=0))
  return t
def cache(pbs,pages=4):
 stride=math.ceil(pbs*584/576)*576
 raw=torch.zeros((pages,stride),dtype=torch.uint8,device='cuda')
 rows=raw[:,:pbs*576].reshape(pages,pbs,576)
 rows[:,:,:448]=torch.full((pages,pbs,448),.5,dtype=torch.float8_e4m3fn,device='cuda').view(torch.uint8)
 rows[:,:,448:]=torch.full((pages,pbs,64),.5,dtype=torch.bfloat16,device='cuda').view(torch.uint8)
 raw[:,pbs*576:pbs*584]=127
 return raw.as_strided((pages,pbs,1,584),(stride,584,584,1))
def indices(rows,pbs,width):
 x=torch.full((rows,1,width),-1,dtype=torch.int32,device='cuda')
 x[:,:,0:8]=torch.arange(pbs,pbs+8,dtype=torch.int32,device='cuda').view(1,1,8)
 # One entirely valid row proves poison affects padding, not ordinary K/V.
 x[0,0,:]=pbs+torch.arange(width,dtype=torch.int32,device='cuda')%pbs
 return x
def evaluate(m,rows,extra_pbs,fill):
 buffers.clear();allocator=Allocator(fill);m.torch=allocator
 q=torch.randn((rows,1,8,512),dtype=torch.bfloat16,device='cuda')*.125
 kv=cache(256);idx=indices(rows,256,128)
 extra=None if extra_pbs is None else cache(extra_pbs)
 extra_idx=None if extra is None else indices(rows,extra_pbs,512)
 args=dict(q=q,k_cache=kv,indices=idx,topk_length=None,attn_sink=None,head_dim_v=512,softmax_scale=512**-.5,
           extra_k_cache=extra,extra_indices_in_kvcache=extra_idx,extra_topk_length=None)
 y,_=m.flash_mla_with_kvcache_sm120(**args)
 torch.cuda.synchronize()
 assert y.shape==(rows,1,8,512),y.shape
 finite=torch.isfinite(y).reshape(rows,-1).all(-1)
 deviation=float((y.float()-.5).abs()[torch.isfinite(y)].max().item())
 split={k:v for k,v in buffers.items() if k.startswith('flash_mla_sm120_split:')}
 assert len(split)==(2 if extra is not None and rows>64 else 1),(rows,extra_pbs,list(split))
 zero_pages={k:bool((v[0]==0).all()) for k,v in split.items()}
 result=dict(rows=rows,extra_page_size=extra_pbs,fill=fill,finite_rows=int(finite.sum()),nonfinite_rows=int((~finite).sum()),
             valid_row_finite=bool(finite[0]),max_finite_absolute_error=deviation,zero_pages=zero_pages,allocations=allocator.allocations)
 if m is new:
  assert all(zero_pages.values()) and bool(finite.all()) and deviation<=.008,result
  ptrs={k:v.data_ptr() for k,v in split.items()}
  y2,_=m.flash_mla_with_kvcache_sm120(**args);torch.cuda.synchronize()
  assert torch.equal(y,y2) and ptrs=={k:buffers[k].data_ptr() for k in ptrs}
  assert all(x['kind']=='zeros' for x in allocator.allocations)
  result['reuse_exact']=True
 elif fill==0:
  assert bool(finite.all()) and deviation<=.008,result
 else:
  assert bool(finite[0]),result
 return result

torch.manual_seed(39288)
results=[]
for rows in [8,64,65,66,128]:
 for extra in [None,128,256]:
  triplet={label:evaluate(m,rows,extra,fill) for label,m,fill in [('old_finite_control',old,0),('old_poisoned',old,255),('fixed',new,255)]}
  if rows>64:assert triplet['old_poisoned']['nonfinite_rows']>0,triplet
  results.append(triplet)
  (out/'partial-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(dict(rank=rank,rows=rows,extra=extra,old_nan=triplet['old_poisoned']['nonfinite_rows'],fixed_nan=triplet['fixed']['nonfinite_rows'])),flush=True)

# Direct splitter checks: touched-page bytes, grow/shrink, and independent tags.
buffers.clear();new.torch=Allocator(255);allocation=[]
for pbs in [128,256]:
 for pages in [3,3,2,5]:
  src=cache(pbs,pages);idx=indices(65,pbs,128)
  got=new._split_kv_pages_to_64(src,pbs,touched_indices=idx,buffer_tag=f'test{pbs}')
  keys={k:v for k,v in buffers.items() if k.startswith(f'flash_mla_sm120_split:cuda:0:test{pbs}')};assert len(keys)==1
  raw=next(iter(keys.values()));assert bool((raw[:pbs//64]==0).all())
  # Compare the referenced source page against full-copy output from old code.
  prior=buffers.copy();buffers.clear();old.torch=Allocator(0)
  ref=old._split_kv_pages_to_64(src,pbs,touched_indices=None,buffer_tag='oracle')
  a=got[pbs//64:2*(pbs//64)];b=ref[pbs//64:2*(pbs//64)]
  assert torch.equal(a,b)
  buffers.clear();buffers.update(prior)
  allocation.append(dict(page_size=pbs,pages=pages,zero_page=True,touched_bytes_exact=True,pointer=raw.data_ptr()))
for pbs in [128,256]:
 rows=[r for r in allocation if r['page_size']==pbs]
 assert rows[0]['pointer']==rows[1]['pointer']==rows[2]['pointer'] and rows[3]['pointer']!=rows[2]['pointer']
buffers.clear();torch.cuda.synchronize()
result=dict(status='PASS',rank=rank,gpu=torch.cuda.get_device_name(),cases=results,splitter=allocation,
            source_hashes={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in ['/tests/source/flash_mla_sm120.py','/candidate/production/python/sglang/kernels/ops/attention/flash_mla_sm120.py']},
            proof='Controlled uint8 allocation poisoning through the actual old/fixed split and FlashInfer wrapper; not a claim of deterministic spontaneous failure in the running model.')
(out/'component-results.json').write_text(json.dumps(result,indent=2)+'\n')
print('SCRATCH_COMPONENT_PASS',rank,flush=True)
