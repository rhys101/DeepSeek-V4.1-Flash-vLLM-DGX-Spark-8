"""Validate preserved partial SSE receipts without qualifying an incomplete block."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

LAB=Path(__file__).resolve().parent.parent/'spark-kernels-iter1'
label=sys.argv[1];assert label.replace('-','').isalnum()
d=LAB/label
read=lambda name:json.loads((d/name).read_text())
assert not (d/'completion.json').exists()
failure=read('failure.json');assert failure==dict(error="BrokenPipeError(32, 'Broken pipe')",completed_rows=13)
config=read('config.json');freeze=read('freeze.json')
assert hashlib.sha256((d/'executed-client.py').read_bytes()).hexdigest()==config['script_sha256']==freeze['client_sha256']
expected=[(4096,1),(32768,1),(131072,1),(299008,1),(32768,8),(131072,8)]
assert [tuple(v) for v in config['cells']]==expected
inputs={}
for key,want in freeze['input_hashes'].items():
 value=read('inputs/'+key+'.json')
 actual=hashlib.sha256(json.dumps(value['tokens'],separators=(',',':')).encode()).hexdigest()
 assert actual==want==value['token_sha256']
 assert len(value['tokens'])==value['context_tokens']
 inputs[key]=value
assert len(inputs)==18 and len(set(freeze['input_hashes'].values()))==18
rows=read('results.json')['rows'];assert len(rows)==13
assert [(r['trial'],r['context_tokens'],r['concurrency']) for r in rows]==[(t,*cell) for t in range(4) for cell in (list(reversed(expected)) if t==2 else expected)][:len(rows)]
def close(a,b):assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9),(a,b)
def idle(value):assert all(x['num_running_reqs']==x['num_waiting_reqs']==0 for x in value['loads'])
maximum_cache=0
for row in rows:
 n,c=row['context_tokens'],row['concurrency']
 assert row==read(f'rows/{n}-c{c}-t{row["trial"]}.json')
 assert row['warmup']==(row['trial']==0)
 for key in ['loads_before','loads_after_flush','loads_after']:idle(row[key])
 assert not any(x in str(row['cache_flush']).lower() for x in ['cannot','failed','error'])
 responses=row['responses'];assert len(responses)==c and [x['slot'] for x in responses]==list(range(c))
 for x in responses:
  assert x['status']=='PASS' and x['input_key']==f'document-{n}-s{x["slot"]}'
  assert x['input_sha256']==freeze['input_hashes'][x['input_key']]
  params=x['request_parameters']
  assert params['sampling_params']==dict(temperature=0,max_new_tokens=1,ignore_eos=True) and params['stream']
  ev=x['events'];assert ev and x['response']==ev[-1]['response']
  generated=[e for e in ev if e['response'].get('meta_info',{}).get('completion_tokens',0)>0]
  close(x['first_token_s'],generated[0]['at_s'])
  close(x['ttft_s'],x['first_token_s']-x['start_s'])
  assert x['start_s']<=x['first_token_s']<=x['finish_s']
  meta=x['response']['meta_info']
  assert meta['prompt_tokens']==n and meta['completion_tokens']==1 and meta.get('num_retractions',0)==0
  assert 0<=meta['cached_tokens']<=64
  maximum_cache=max(maximum_cache,meta['cached_tokens'])
 start=min(x['start_s'] for x in responses)
 seconds=max(x['first_token_s'] for x in responses)-start
 close(row['prefill_seconds'],seconds)
 close(row['complete_seconds'],max(x['finish_s'] for x in responses)-start)
 close(row['input_tokens_per_second'],n*c/seconds)
 close(row['mean_ttft_seconds'],statistics.mean(x['first_token_s']-x['start_s'] for x in responses))
 assert row['input_tokens']==n*c and row['output_tokens']==c
idle(read('loads-before.json'));idle(rows[-1]['loads_after'])
guard=json.loads((LAB/(label+'-guard')/'completion.json').read_text())
assert guard['status']=='PASS'
# The guard records the minimum across every sample and all eight ranks.
minimum=guard.get('minimum_available_gib')
if minimum is None:
 sample_file=LAB/(label+'-guard')/'samples.jsonl'
 samples=[json.loads(line) for line in sample_file.read_text().splitlines()]
 minimum=min(rank['available_gib'] for sample in samples for rank in sample['ranks'])
assert minimum>=2
summaries=[]
for n,c in expected:
 group=[r for r in rows if not r['warmup'] and (r['context_tokens'],r['concurrency'])==(n,c)]
 assert len(group) in (1,2)
 times=[r['prefill_seconds'] for r in group]
 mean=statistics.mean(times)
 summaries.append(dict(context_tokens=n,concurrency=c,seconds=times,mean_prefill_seconds=mean,median_prefill_seconds=statistics.median(times),
                       mean_input_tokens_per_second=statistics.mean(r['input_tokens_per_second'] for r in group),
                       aggregate_rate_from_mean_seconds=n*c/mean))
value=dict(status='PARTIAL_RECEIPTS_VALID_TRANSPORT_FAILED',failure=failure,completed_batches=len(rows),measured_batches=sum(not r['warmup'] for r in rows),label=label,measured_cells=summaries,maximum_reported_cached_tokens=maximum_cache,minimum_available_gib=minimum,
           source_sha256=freeze['client_sha256'],frozen_input_hashes=freeze['input_hashes'])
(d/'partial-validation.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k!='frozen_input_hashes'},indent=2))
