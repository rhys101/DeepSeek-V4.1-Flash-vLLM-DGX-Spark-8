"""Recompute all-rank memory and process continuity from archived guard samples."""
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
image = 'sha256:e7681b5276525821f9be286ed3bf0f51acb5239da27f69f60fdeb57e68c05581'
reports = []
for label in sys.argv[1:]:
    assert label.replace('-', '').isalnum()
    root = LAB / (label + '-guard')
    assert not (root / 'failure.json').exists()
    completion = json.loads((root / 'completion.json').read_text())
    ready = json.loads((root / 'ready.json').read_text())
    assert completion['status'] == 'PASS' and ready['status'] == 'READY'
    raw = (root / 'samples.jsonl').read_bytes()
    samples = [json.loads(line) for line in raw.splitlines()]
    assert len(samples) == completion['samples'] and len(samples) > 1
    minimum = [float('inf')] * 8
    process_identity = None
    stamps = []
    for sample in samples:
        stamps.append(datetime.datetime.fromisoformat(sample['observed']).timestamp())
        rows = sample['ranks']
        assert [r['rank'] for r in rows] == list(range(8))
        identities = []
        for row in rows:
            state = row['state']
            assert state['Running'] and not state['OOMKilled']
            assert row['restarts'] == 0 and row['image'] == image
            assert row['available_gib'] >= 2
            minimum[row['rank']] = min(minimum[row['rank']], row['available_gib'])
            identities.append((state['Pid'], state['StartedAt']))
        if process_identity is None:
            process_identity = identities
        assert identities == process_identity
    assert ready['minimum_available_gib'] == min(r['available_gib'] for r in samples[0]['ranks'])
    assert min(minimum) == completion['minimum_available_gib']
    intervals = [b-a for a,b in zip(stamps, stamps[1:])]
    assert all(gap > 0 for gap in intervals)
    value = dict(status='PASS_RAW_GUARD_SAMPLES', label=label, samples=len(samples),
                 rank_observations=len(samples)*8, minimum_available_gib=min(minimum),
                 minimum_by_rank_gib=minimum, first_observation=samples[0]['observed'],
                 last_observation=samples[-1]['observed'], maximum_sample_interval_seconds=max(intervals),
                 mean_sample_interval_seconds=statistics.mean(intervals),
                 process_identity_unchanged=True, samples_sha256=hashlib.sha256(raw).hexdigest(),
                 scope='Every recorded sample has all eight ranks, the expected image, the same running processes, no recorded OOM/restarts, and at least two GiB OS-available. Sampling does not observe every instant.')
    destination = PF / (label + '-raw-guard-validation-v01.json')
    assert not destination.exists()
    destination.write_text(json.dumps(value, indent=2) + '\n')
    reports.append({k:value[k] for k in ['status','label','samples','minimum_available_gib','maximum_sample_interval_seconds']})
print(json.dumps(reports, indent=2))
