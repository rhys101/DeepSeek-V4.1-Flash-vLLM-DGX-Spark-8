"""Compare both unchanged README repetitions and bounded answer fixtures."""
import json
from pathlib import Path
import statistics
import sys

PF=Path(__file__).resolve().parent;LAB=PF.parent/'spark-kernels-iter1'
candidate=sys.argv[1];controls=sys.argv[2:]
assert len(controls)==2
for label in [candidate,*controls]:assert label.replace('-','').isalnum()
def read(label,name):return json.loads((LAB/label/name).read_text())
def validation(label):
 v=read(label,'readme-validation.json');assert v['status']=='PASS';return v
cand=validation(candidate);bases=[validation(label) for label in controls]
assert all(read(label,'reference-manifest.json')==read(candidate,'reference-manifest.json') for label in controls)
metrics=['coding_decode_per_stream','coding_full_batch_aggregate','prose_decode_aggregate','prose_decode_per_stream']
comparisons=[]
for label,base in zip(controls,bases):
 rows=[]
 for concurrency in [1,4,8]:
  for metric in metrics:
   repetitions=[]
   for phase in ['benchmark-initial','benchmark-repeat']:
    a=next(x for x in base['runs'][phase]['rows'] if x['concurrency']==concurrency)[metric]
    b=next(x for x in cand['runs'][phase]['rows'] if x['concurrency']==concurrency)[metric]
    ratio=b['mean']/a['mean']
    repetitions.append(dict(phase=phase,baseline_mean=a['mean'],candidate_mean=b['mean'],baseline_trials=a['values'],candidate_trials=b['values'],
                            rate_ratio=ratio,change_percent=100*(ratio-1),decline_over_three_percent=ratio<.97))
   repeatable=all(x['decline_over_three_percent'] for x in repetitions)
   rows.append(dict(concurrency=concurrency,metric=metric,repetitions=repetitions,repeatable_decline_over_three_percent=repeatable,
                    prevents_promotion=concurrency in (1,8) and repeatable))
 comparisons.append(dict(control=label,rows=rows,gate_pass=not any(x['prevents_promotion'] for x in rows)))

def normalize(value):
 response=value.get('response',value)
 message=response['choices'][0]['message']
 content=(message.get('content') or '').strip()
 try:content=json.dumps(json.loads(content),sort_keys=True,separators=(',',':'))
 except (ValueError,TypeError):pass
 calls=[]
 for call in message.get('tool_calls') or []:
  f=call['function'];args=f['arguments']
  try:args=json.loads(args) if isinstance(args,str) else args
  except ValueError:pass
  calls.append(dict(name=f['name'],arguments=args))
 return dict(content=content,tool_calls=calls)

answers=[]
for p in sorted((LAB/candidate/'acceptance').glob('*.json')):
 if p.name=='result.json':continue
 known=[]
 for label in controls:
  for phase in ['acceptance','acceptance-after']:
   value=normalize(read(label,phase+'/'+p.name))
   if value not in known:known.append(value)
 for phase in ['acceptance','acceptance-after']:
  value=normalize(read(candidate,phase+'/'+p.name))
  answers.append(dict(fixture=p.name,phase=phase,category='short capability',matches_control_repetition=value in known,
                      candidate=value,observed_controls=known))
for context in [32768,131072,299000]:
 path=f'long-context/{context}-response.json'
 known=[normalize(read(label,path)) for label in controls]
 value=normalize(read(candidate,path))
 assert value in known,(context,value,known)
 answers.append(dict(fixture=path,category='long retrieval',matches_control_repetition=True,candidate=value,observed_controls=known))
# Existing validator independently requires every C128 arithmetic response and
# all capability/retrieval expectations; wording changes remain explicit here.
changes=[row for row in answers if not row['matches_control_repetition']]
value=dict(status='PASS_README_COMPARISON' if all(x['gate_pass'] for x in comparisons) else 'REVIEW_REQUIRED',
           candidate=candidate,controls=controls,comparisons=comparisons,answers=answers,new_answer_variants=changes,
           quality_scope='All unchanged capability expectations, exact C128 arithmetic and three long retrieval answers pass independently. New short-answer wording is listed for review against four baseline repetitions; this is a bounded check.')
path=PF/(candidate+'-comparison-v01.json');assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(status=value['status'],candidate=candidate,new_answer_variants=len(changes),controls=[dict(control=x['control'],gate_pass=x['gate_pass']) for x in comparisons]),indent=2))
