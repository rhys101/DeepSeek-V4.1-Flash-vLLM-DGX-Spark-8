"""Require validated controls to precede and follow the candidate in time."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

mode, candidate, before, after = sys.argv[1:5]
assert mode in ('cold', 'readme')
assert len({candidate, before, after}) == 3
assert all(label.replace('-', '').isalnum() for label in [candidate, before, after])
pf = Path(__file__).resolve().parent
lab = pf.parent / 'spark-kernels-iter1'
evidence = {}


def read(label, name):
    raw = (lab / label / name).read_bytes()
    evidence[label + '/' + name] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def stamp(value):
    value = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert value.utcoffset() is not None
    return value


rows = []
for role, label in [('before', before), ('candidate', candidate), ('after', after)]:
    validation = read(label, 'prefill-validation.json' if mode == 'cold' else 'readme-validation.json')
    assert validation['status'] == 'PASS'
    start = read(label, 'loads-before.json')['timestamp']
    completion = read(label, 'completion.json')
    assert completion['status'] == 'PASS'
    finish = completion['finished']
    assert stamp(start) < stamp(finish)
    rows.append(dict(role=role, label=label, start=start, finish=finish))

gaps = []
for left, right in zip(rows, rows[1:]):
    gap = (stamp(right['start']) - stamp(left['finish'])).total_seconds()
    assert gap > 0, (left, right)
    gaps.append(gap)

value = dict(status='PASS_TEMPORAL_BRACKET', mode=mode, candidate=candidate,
             controls=[before, after], runs=rows, separating_seconds=gaps,
             evidence_sha256=evidence,
             scope='Recorded run-start and completion timestamps place the validated controls on opposite sides of the candidate. Numerical gates and source/prompt identity are checked separately.')
destination = pf / (candidate + '-temporal-bracket-v01.json')
assert not destination.exists()
destination.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value, indent=2))
