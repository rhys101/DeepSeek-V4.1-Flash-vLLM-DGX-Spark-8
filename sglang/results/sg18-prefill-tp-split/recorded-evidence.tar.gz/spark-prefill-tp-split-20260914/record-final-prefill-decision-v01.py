"""Record non-promotion only after independent failure review and healthy rollback."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
evidence = {}


def read(path):
    raw = path.read_bytes()
    evidence[str(path.relative_to(PF.parent))] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


failure = read(PF / 'prefill-capacity-failure-audit-v01.json')
assert failure['status'] == 'FAIL_CAPACITY_MEMORY_GATE'
assert failure['evidence_audit_status'] == 'PASS_FAILURE_RECONSTRUCTION'
audit = read(LAB / 'prefill-final-baseline-audit-v01.json')
assert audit['status'] == 'PASS' and all(not jobs for jobs in audit['active_experiment_jobs'].values())
assert len(audit['ranks']) == 8
for rank, row in enumerate(audit['ranks']):
    assert row['rank'] == rank and row['candidate'] == f'sglang8-sparkkernels-scratchfix01-r{rank}'
    assert row['running_gpu_containers'] == [row['candidate']]
    assert row['state']['Running'] and not row['state']['OOMKilled'] and row['available_gib'] >= 2
    assert not row['original_state']['Running']
    assert {item['container'] for item in row['preserved_baselines']} == {
        f'sglang8-sparkkernels-readmeihw01-r{rank}', f'sglang8-sparkkernels-prefillnative01-r{rank}'}
    assert all(not item['state']['Running'] for item in row['preserved_baselines'])
    assert len(row['source_and_cache_hashes']) == 262
startup = read(LAB / 'startup-fixedfinalrestore01/completion.json')
runtime = read(LAB / 'startup-fixedfinalrestore01/runtime-contract.json')
cache = read(LAB / 'startup-fixedfinalrestore01/autotune-control.json')
assert startup['status'] == 'READY' and startup['minimum_available_gib'] >= 2
assert runtime['status'] == 'PASS' and runtime['identical_top_level_settings'] == 500 and runtime['checked_source_ranks'] == 8
assert cache['status'] == 'CACHE_FILES_VERIFIED_DISPATCH_REQUIRED' and cache['attempt'] == 'scratchfix01'
assert read(LAB / 'prefill-profile4k-fixed-v01-dispatch-validation.json')['status'] == 'PASS'
assert read(LAB / 'prefill-readme-fixed-confirmation-after-v01/readme-validation.json')['status'] == 'PASS'
prerequisites = read(PF / 'prefill-confirmation-decision-v01.json')
assert prerequisites['status'] == 'PASS_PRECAPACITY'
assert read(PF / 'prefill-native-confirmation-v01-timing-bracket.json')['status'] == 'PASS_TIMING_BRACKET'
assert read(PF / 'prefill-readme-native-confirmation-v01-comparison-v01.json')['status'] == 'PASS_README_COMPARISON'
assert read(PF / 'review-source-final-validation-v01.json')['status'] == 'PASS_SOURCE_ONLY'
repo = PF.parent / 'readme-promotion-20260914/repo'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == '1933f182f1bdcce2872699ac06de5bd3fc4c4980'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
value = dict(status='NOT_PROMOTED_BASELINE_RESTORED', recorded=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             candidate='prefillnative01', active_service='scratchfix01',
             reason='FAIL_CAPACITY_MEMORY_GATE', handoff_audit_status='PASS', handoff_observed=audit['observed'],
             active_ranks=8, minimum_handoff_available_gib=min(row['available_gib'] for row in audit['ranks']),
             minimum_restoration_startup_available_gib=startup['minimum_available_gib'],
             active_experiment_jobs=audit['active_experiment_jobs'],
             capacity_completed_retrievals=0, capacity_simultaneous_residency_proven=False,
             primary_confirmation_time_reductions_percent=[item['primary_time_reduction_percent'] for item in prerequisites['cold_comparisons']],
             candidate_and_prior_baseline_sources_and_caches_preserved=True,
             publication='No candidate source, results or README headline changes were pushed. The conditional promotion gate failed; the review draft is retained locally.',
             unchanged_original_repository_head=head, evidence_sha256=evidence,
             next_investigation='Attribute head-node memory pressure during near-1M prefill before another capacity qualification. The OS-only samples do not isolate the split as the cause; retain the two-GiB threshold and original capacity criteria.')
destination = PF / 'prefill-final-decision-v01.json'
assert not destination.exists()
destination.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key:item for key,item in value.items() if key != 'evidence_sha256'}, indent=2))
