"""Reconstruct the failed capacity gate without qualifying incomplete retrievals."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import random
import re

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
LABEL = 'prefill-capacity-native-v01'
D = LAB / LABEL
G = LAB / (LABEL + '-guard')
evidence = {}


def bytes_from(path):
    raw = path.read_bytes()
    evidence[str(path.relative_to(PF.parent))] = hashlib.sha256(raw).hexdigest()
    return raw


def read(path):
    return json.loads(bytes_from(path))


result = read(D / 'result.json')
assert result['status'] == 'FAIL' and result['phase'] == 'failed'
assert not (D / 'completion.json').exists() and not (G / 'completion.json').exists()
assert result['residency_proof'] is None and set(result['phases']) == {'cold'}
config = read(D / 'config.json')
launch = read(LAB / (LABEL + '-durable-launch.json'))
controller = read(LAB / (LABEL + '-durable-status.json'))
assert controller['status'] == 'FAIL' and controller['controller_returncode'] == 1
client_sha = hashlib.sha256(bytes_from(D / 'executed-client.py')).hexdigest()
assert client_sha == config['script_sha256'] == launch['files']['prefill-capacity-client-v01.py']
assert hashlib.sha256(bytes_from(D / 'executed-controller.py')).hexdigest() == controller['controller_sha256']
assert hashlib.sha256(bytes_from(G / 'executed-guard.py')).hexdigest() == launch['files']['prefill-capacity-guard-v01.py']
freeze = read(D / 'freeze.json')
assert freeze['client_sha256'] == client_sha and freeze['prompts'] == result['prompts']
assert len(freeze['prompts']) == 8
for index, receipt in enumerate(freeze['prompts']):
    rng = random.Random(8161900 + index)
    expected = {name: str(rng.randrange(10000000, 100000000)) for name in ('alpha', 'beta', 'gamma')}
    assert receipt['index'] == index and receipt['expected'] == expected
    prompt = bytes_from(D / f'prompt-{index}.txt')
    assert hashlib.sha256(prompt).hexdigest() == receipt['prompt_sha256']
    assert len(prompt) == receipt['bytes'] and 996900 <= receipt['prompt_tokens'] < 998000
    assert dict(re.findall(r'^RECORD (alpha|beta|gamma)=(\d{8})$', prompt.decode(), re.MULTILINE)) == expected
assert len({row['prompt_sha256'] for row in freeze['prompts']}) == 8
requests = result['phases']['cold']['requests']
assert len(requests) == 8 and [row['index'] for row in requests] == list(range(8))
assert all(row['status'] == 'FAIL' and not row['text'] and not row['usage'] for row in requests)
assert all(row['error'] == result['error'] for row in requests)

raw = bytes_from(G / 'samples.jsonl')
samples = [json.loads(line) for line in raw.splitlines()]
assert len(samples) > 1
identities = None
for sample in samples:
    ranks = sample['ranks']
    assert [row['rank'] for row in ranks] == list(range(8))
    current = [(row['state']['Pid'], row['state']['StartedAt']) for row in ranks]
    if identities is None:
        identities = current
    assert current == identities
    assert all(row['state']['Running'] and not row['state']['OOMKilled'] and row['restarts'] == 0 for row in ranks)
    assert all(row['image'] == 'sha256:e7681b5276525821f9be286ed3bf0f51acb5239da27f69f60fdeb57e68c05581' for row in ranks)
assert all(row['available_gib'] >= 2 for sample in samples[:-1] for row in sample['ranks'])
crossing = [row for row in samples[-1]['ranks'] if row['available_gib'] < 2]
assert [row['rank'] for row in crossing] == [0]
minimum = min(row['available_gib'] for sample in samples for row in sample['ranks'])
failure = read(G / 'failure.json')
assert failure['minimum_available_gib'] == minimum == crossing[0]['available_gib']
assert failure['error'].startswith('AssertionError(') and failure['error'].endswith(')')
assert ast.literal_eval(failure['error'][len('AssertionError('):-1]) == samples[-1]['ranks']
first = datetime.datetime.fromisoformat(samples[0]['observed'])
last = datetime.datetime.fromisoformat(samples[-1]['observed'])
assert 0 < (last - first).total_seconds() < 21600
loads = [json.loads(line) for line in bytes_from(D / 'loads.jsonl').splitlines()]
valid = [sample for sample in loads if sample.get('response', {}).get('loads')]
proofs = []
for sample in valid:
    stamp = datetime.datetime.fromisoformat(sample['observed']).timestamp()
    for load in sample['response']['loads']:
        if (load['num_running_reqs'] == 8 and load['num_waiting_reqs'] == 0
                and load['num_used_tokens'] > 7900000 and load['num_active_tokens'] > 7900000
                and -2 <= stamp - load['timestamp'] <= 10):
            proofs.append(sample)
assert not proofs
states = read(PF / 'capacity-failure-live-v01/states.json')
assert len(states['ranks']) == 8
assert all(not row['state']['Running'] and not row['state']['OOMKilled'] and row['restarts'] == 0 for row in states['ranks'])
error_markers = {}
for rank in range(8):
    logs = bytes_from(PF / f'capacity-failure-live-v01/r{rank}.log').decode()
    error_markers[rank] = [line for line in logs.splitlines() if re.search(
        r'CUDA out of memory|OutOfMemoryError|illegal memory access|device-side assert|Scheduler hit an exception', line)]
controller_log = bytes_from(LAB / (LABEL + '-durable-controller.log')).decode()
assert 'process.wait(timeout=90)' in controller_log and 'subprocess.TimeoutExpired' in controller_log
value = dict(status='FAIL_CAPACITY_MEMORY_GATE', label=LABEL,
             evidence_audit_status='PASS_FAILURE_RECONSTRUCTION',
             prompt_tokens=[row['prompt_tokens'] for row in freeze['prompts']],
             submitted_prompt_tokens=sum(row['prompt_tokens'] for row in freeze['prompts']),
             completed_cold_retrievals=0, cached_phase_started=False, simultaneous_residency_samples=0,
             guard_samples=len(samples), guard_rank_observations=len(samples) * 8,
             guard_first_observation=samples[0]['observed'], memory_threshold_crossed_at=samples[-1]['observed'],
             minimum_available_gib=minimum, below_threshold_ranks=[0],
             final_available_by_rank_gib=[row['available_gib'] for row in samples[-1]['ranks']],
             worker_processes_unchanged_and_running_until_guard_stop=True,
             recorded_oom_kills=0, post_stop_exit_codes=[row['state']['ExitCode'] for row in states['ranks']],
             load_samples=len(loads), last_successful_load=valid[-1],
             worker_cuda_or_scheduler_error_markers=error_markers,
             controller_cleanup='Sequential eight-rank stop exceeded the 90-second finalizer wait; all raw guard files were recovered directly from the head.',
             evidence_sha256=evidence,
             interpretation='The fixed two-GiB OS-memory gate stopped the candidate before any near-1M retrieval completed. The head node was below the threshold; the other seven were above it. This is neither an answer mismatch nor an observed OOM kill. The saved OS-only samples do not identify which allocation caused the pressure, and no matched near-1M fixed-baseline run was performed in this experiment. Do not attribute the pressure specifically to the split from these records alone.')
destination = PF / 'prefill-capacity-failure-audit-v01.json'
assert not destination.exists()
destination.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({key:item for key,item in value.items() if key not in ['evidence_sha256', 'last_successful_load']}, indent=2))
