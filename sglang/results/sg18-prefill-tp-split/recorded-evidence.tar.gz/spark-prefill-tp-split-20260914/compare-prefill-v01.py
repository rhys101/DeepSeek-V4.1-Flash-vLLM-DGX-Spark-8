"""Keep every cell and compare frozen-input timing blocks without rounding gates."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

PF=Path(__file__).resolve().parent;LAB=PF.parent/'spark-kernels-iter1'
candidate=sys.argv[1];controls=sys.argv[2:]
assert len(controls) in (1,2)
for name in [candidate,*controls]:assert name.replace('-','').isalnum()
def read(label):
 value=json.loads((LAB/label/'prefill-validation.json').read_text());assert value['status']=='PASS'
 return value
c=read(candidate);bases=[read(label) for label in controls]
for b in bases:
 assert b['frozen_input_hashes']==c['frozen_input_hashes'] and b['source_sha256']==c['source_sha256']
key=lambda row:(row['context_tokens'],row['concurrency'])
rows_c={key(row):row for row in c['measured_cells']}
primary={(131072,1),(299008,1),(131072,8)}
short={(4096,1),(32768,1),(32768,8)}
results=[]
for b in bases:
 rows_b={key(row):row for row in b['measured_cells']}
 cells=[]
 for cell,x in rows_c.items():
  y=rows_b[cell];ratio=x['mean_prefill_seconds']/y['mean_prefill_seconds']
  cells.append(dict(context_tokens=cell[0],concurrency=cell[1],primary=cell in primary,
                    baseline_mean_seconds=y['mean_prefill_seconds'],candidate_mean_seconds=x['mean_prefill_seconds'],
                    candidate_seconds=x['seconds'],baseline_seconds=y['seconds'],
                    time_ratio=ratio,time_reduction_percent=100*(1-ratio),throughput_increase_percent=100*(1/ratio-1),
                    short_regression_over_three_percent=cell in short and ratio>1.03))
 gm=math.exp(statistics.mean(math.log(cell['time_ratio']) for cell in cells if cell['primary']))
 results.append(dict(control=b['label'],cells=cells,primary_geomean_time_ratio=gm,primary_time_reduction_percent=100*(1-gm),
                     primary_gate=gm<=.97,short_gates=not any(x['short_regression_over_three_percent'] for x in cells)))
status='PASS_TIMING_BRACKET' if len(controls)==2 and all(r['primary_gate'] and r['short_gates'] for r in results) else 'PASS_INITIAL_SCREEN' if len(controls)==1 and all(r['primary_gate'] and r['short_gates'] for r in results) else 'REVIEW_REQUIRED'
value=dict(status=status,candidate=candidate,controls=controls,comparisons=results,
           note='A single preceding control is a screen. Promotion also requires the following SG18 control, README/quality/dispatch/capacity/health gates. Every measured trial remains included.',
           source_sha256=c['source_sha256'])
path=PF/(candidate+'-timing-'+('bracket' if len(controls)==2 else 'screen')+'.json');assert not path.exists()
path.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
