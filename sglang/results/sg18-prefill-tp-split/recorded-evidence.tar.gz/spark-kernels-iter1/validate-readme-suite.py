"""Validate recorded README requests and summarize every measured trial."""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

lab = Path(__file__).resolve().parent
label = sys.argv[1]
assert label.replace('-', '').isalnum()
root = lab / label
reference = lab.parent / 'readme-promotion-20260914/reference-kit'
published = lab.parent / 'readme-promotion-20260914/repo/sglang/results/sg17-rocenante'
evidence = {}


def read(path):
    raw = path.read_bytes()
    evidence[str(path)] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def close(actual, expected, tolerance=1e-7):
    assert math.isfinite(actual) and abs(actual - expected) <= tolerance, (actual, expected, tolerance)


def stats(values):
    return dict(values=values, mean=statistics.mean(values), minimum=min(values), maximum=max(values),
                sample_stdev=statistics.stdev(values) if len(values) > 1 else 0)


def parse_content(text):
    text = text.strip()
    if text.startswith('```'):
        text = text.split('\n', 1)[1].rsplit('```', 1)[0].strip()
    return json.loads(text)


completion = read(root / 'completion.json')
guard = read(lab / (label + '-guard/completion.json'))
assert completion['status'] == guard['status'] == 'PASS' and guard['minimum_available_gib'] >= 2
config = read(root / 'config.json')
assert hashlib.sha256((root / 'executed-client.py').read_bytes()).hexdigest() == config['script_sha256']
manifest = read(root / 'reference-manifest.json')
assert manifest == read(reference / 'reference-manifest.json')
for name, digest in manifest['files'].items():
    assert hashlib.sha256((reference / name).read_bytes()).hexdigest() == digest
for name in ['loads-before.json', 'loads-after.json']:
    assert all(row['num_running_reqs'] == row['num_waiting_reqs'] == 0 for row in read(root / name)['loads'])

fixture = read(reference / 'sglang/validation/vision-fixtures/expected.json')
for phase in ['acceptance', 'acceptance-after']:
    folder = root / phase
    assert read(folder / 'result.json')['status'] == 'PASS'

    def message(name):
        return read(folder / (name + '.json'))['response']['choices'][0]['message']

    assert message('arithmetic')['content'].strip() == '323'
    for trial in [1, 2]:
        for index in range(8):
            assert message(f'batch-{trial}-{index}')['content'].strip() == str((17 + index) * 19)
    assert parse_content(message('single-image')['content']) == fixture['single']
    assert parse_content(message('four-images')['content']) == fixture['four']
    assert parse_content(message('structured')['content']) == {'answer': 42}
    calls = message('tool-call')['tool_calls']
    assert len(calls) == 1 and calls[0]['function']['name'] == 'lookup_fixture'
    assert json.loads(calls[0]['function']['arguments']) == {'key': 'alpha'}
    assert '42' in message('tool-result')['content']

arithmetic = read(root / 'arithmetic-c128.json')
assert len(arithmetic) == 128 and sorted(row['index'] for row in arithmetic) == list(range(128))
for row in arithmetic:
    assert row['expected'] == row['actual'] == row['response']['choices'][0]['message']['content'].strip() == str(40 + row['index'])
    assert row['passed'] and row['request']['max_tokens'] == 16 and row['request']['temperature'] == 0

long_context = read(root / 'long-context/result.json')
old_long = read(published / 'long-context.json')
assert long_context['status'] == 'PASS' and long_context['tag'] == old_long['tag']
assert len(long_context['cases']) == len(old_long['cases']) == 3
for actual, expected in zip(long_context['cases'], old_long['cases']):
    for field in ['filler_units', 'prompt_sha256', 'expected']:
        assert actual[field] == expected[field], field
    response = read(root / 'long-context' / (str(actual['filler_units']) + '-response.json'))
    assert parse_content(response['choices'][0]['message']['content']) == actual['actual'] == expected['expected']
    assert actual['passed'] and actual['usage']['prompt_tokens'] == expected['usage']['prompt_tokens']

runs = {}
published_prose = read(published / 'runs/sg17_repeat/prose-metrics.json')
prose_reference = {
    (row['concurrency'], stream['index']): stream
    for row in published_prose['decode'][0]['results'] for stream in row['streams']
}
for phase in ['benchmark-initial', 'benchmark-repeat']:
    folder = root / phase
    assert read(folder / 'completion.json')['status'] == 'PASS'
    info = read(folder / 'server-info.json')
    assert [info[key] for key in ['tp_size', 'ep_size', 'context_length', 'max_total_tokens', 'max_running_requests', 'speculative_dspark_block_size', 'chunked_prefill_size']] == [8, 4, 1000000, 8000000, 128, 5, 2048]
    coding = read(folder / 'coding.json')
    assert coding['source_sha256'] == manifest['files']['bench/v41bench.py']
    expected_order = [(1, 1), (1, 4), (1, 8), (2, 8), (2, 4), (2, 1), (3, 1), (3, 4), (3, 8), (4, 1), (5, 1)]
    assert [(row['trial'], row['c']) for row in coding['batches']] == expected_order
    assert [row['c'] for row in coding['excluded_coding_warmups']] == [1, 4, 8]
    code_groups = defaultdict(list)
    for row in [*coding['excluded_coding_warmups'], *coding['batches']]:
        assert row['category'] == 'coding' and len(row['requests']) == row['c']
        assert row['tokens'] == 200 * row['c']
        for request in row['requests']:
            assert request['completion_tokens'] == 200 and request['prompt_tokens'] == 47
            assert 0 < request['ttft_s'] < request['total_s']
            close(request['decode_tok_s'], 199 / (request['total_s'] - request['ttft_s']))
        close(row['per_stream_tok_s'], round(statistics.mean(request['decode_tok_s'] for request in row['requests']), 2))
        close(row['ttft_mean_s'], round(statistics.mean(request['ttft_s'] for request in row['requests']), 3))
        assert row['wall_s'] + .000501 >= max(request['total_s'] for request in row['requests'])
        assert row['tokens'] / (row['wall_s'] + .000501) - .00501 <= row['agg_tok_s'] <= row['tokens'] / (row['wall_s'] - .000501) + .00501
        if 'trial' in row:
            code_groups[row['c']].append(row)
    prose = read(folder / 'sparkdash/result.json')
    assert prose['status'] == 'PASS' and prose['source'] == read(reference / 'sglang/bench/sparkdash/upstream.lock.json')
    assert prose['config']['levels'] == '1,4,8' and prose['config']['trials'] == '3' and prose['config']['sizes'] == '4096'
    assert len(prose['prefill']) == 3 and len(prose['decode']) == 3
    prose_groups = defaultdict(list)
    for trial in prose['decode']:
        job = trial['job']
        assert job['status'] == 'completed' and [row['concurrency'] for row in job['results']] == [1, 4, 8]
        for row in job['results']:
            count = row['concurrency']
            assert not row['error'] and row['streamsFailed'] == 0 and row['streamsOk'] == count == len(row['streams'])
            assert row['totalDecodeTokens'] == 255 * count and row['totalCompletionTokens'] == 256 * count
            assert row['totalPrefillTokens'] == sum(stream['prefillTokens'] for stream in row['streams'])
            for stream in row['streams']:
                assert not stream['error'] and stream['completionTokens'] == stream['usage']['completionTokens'] == 256
                expected_stream = prose_reference[count, stream['index']]
                assert stream['decodeTokens'] == 255 and stream['prefillTokens'] == stream['usage']['promptTokens'] == expected_stream['prefillTokens']
                assert stream['prompt'] == expected_stream['prompt']
                assert stream['http']['finishReason'] == 'length' and stream['reasoningChunks'] == 0
                close(stream['decodeTps'], 255000 / stream['decodeMs'], .006)
            close(row['meanDecodeTps'], statistics.mean(stream['decodeTps'] for stream in row['streams']), .006)
            assert 0 < row['aggregateDecodeTps'] <= sum(stream['decodeTps'] for stream in row['streams']) + .02
            prose_groups[count].append(row)
    rows = []
    for count in [1, 4, 8]:
        code = code_groups[count]
        pro = prose_groups[count]
        assert len(code) == (5 if count == 1 else 3) and len(pro) == 3
        rows.append(dict(concurrency=count,
            coding_decode_per_stream=stats([row['per_stream_tok_s'] for row in code]),
            coding_full_batch_aggregate=stats([row['agg_tok_s'] for row in code]),
            coding_ttft_seconds=stats([row['ttft_mean_s'] for row in code]),
            prose_decode_aggregate=stats([row['aggregateDecodeTps'] for row in pro]),
            prose_decode_per_stream=stats([row['meanDecodeTps'] for row in pro]),
            prose_ttft_ms=stats([row['meanTtftMs'] for row in pro])))
    runs[phase] = dict(rows=rows, measured_coding_requests=41, measured_prose_requests=39,
                       completed=read(folder / 'completion.json')['finished'])

result = dict(status='PASS', label=label, runs=runs, guard=guard,
    capability_checks='PASS before and after; exact C128 arithmetic 128/128; original three retrieval prompt hashes and answer values match.',
    source_commit=manifest['source_commit'], evidence_sha256=evidence,
    controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    limitation='Collection, source identity, contracts and recorded token/rate accounting passed. Prose aggregate follows the verified pinned runner; absolute first/last endpoints are not retained, so its exact aggregate cannot be independently reconstructed. This is not a broad quality or promotion decision.')
destination = root / 'readme-validation.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status='PASS', label=label, runs={phase: value['rows'] for phase, value in runs.items()}, minimum_available_gib=guard['minimum_available_gib'])))
