"""Frozen cold-prefill trials; minimal output and complete request receipts."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys
import threading
import time
import urllib.request

c = json.loads(Path(sys.argv[1]).read_text())
out = Path(c['out']); out.mkdir(parents=True, exist_ok=False)
base = c['base'].rstrip('/')

def save(name, value):
    p = out/name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2)+'\n')

def api(route, body=None, timeout=1200):
    req = urllib.request.Request(base+route, None if body is None else json.dumps(body).encode(), {'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read()
        try: return json.loads(raw)
        except json.JSONDecodeError: return raw.decode()

def idle():
    deadline = time.monotonic()+90
    while time.monotonic()<deadline:
        value = api('/v1/loads', timeout=20)
        if all(x['num_running_reqs']==x['num_waiting_reqs']==0 for x in value['loads']): return value
        time.sleep(.2)
    raise TimeoutError('Server did not become idle')

def digest(tokens):
    return hashlib.sha256(json.dumps(tokens,separators=(',',':')).encode()).hexdigest()

def make_input(length, slot):
    seed = 91426000+length*13+slot*977
    rng = random.Random(seed)
    task = 'Describe the main coordination problems in these records and explain a practical improvement. Use the document as evidence.'
    records=[]
    for i in range(length//35+100):
        a,b,d=[rng.randrange(1,1000) for _ in range(3)]
        records.append(f'Record {i}: group {a} reviewed project {b}, allocating {d} units of capacity. The review distinguished completed work from forecasts. Dependencies, unresolved questions and recovery steps were written down before the next handoff. Participants compared the evidence with their earlier estimates and adjusted the next milestone.\n')
    text=f'Independent prefill document {seed}.\n{task}\n<records>\n'+''.join(records)+'\n</records>\n'+task
    rendered=api('/v1/tokenize',dict(model='deepseek-v41-flash',messages=[dict(role='user',content=text)],chat_template_kwargs={'thinking':False}))
    tokens=rendered['tokens']; assert len(tokens)>length+256,(len(tokens),length)
    tokens=tokens[:length-256]+tokens[-256:]
    return dict(context_tokens=length,slot=slot,seed=seed,tokens=tokens,token_sha256=digest(tokens),
                construction='Deterministic independent synthetic document; remove a middle span from rendered chat, retaining the final 256 task/template tokens.')

cells=[(int(x),int(y)) for x,y in c['cells']]
assert cells==[(4096,1),(32768,1),(131072,1),(299008,1),(32768,8),(131072,8)]
assert c['measured_trials']==3
save('config.json',c);save('loads-before.json',idle())
info=api('/server_info');save('server-info.json',info)
assert (info['tp_size'],info['ep_size'],info['context_length'],info['max_total_tokens'],info['max_running_requests'],info['speculative_dspark_block_size'])==(8,4,1000000,8000000,128,5)
inputs={}
for length,concurrency in cells:
    for slot in range(concurrency):
        key=f'document-{length}-s{slot}'
        if key in inputs:continue
        if c.get('inputs_from'):
            value=json.loads((Path(c['inputs_from'])/'inputs'/(key+'.json')).read_text())
        else:value=make_input(length,slot)
        assert value['context_tokens']==len(value['tokens'])==length and value['token_sha256']==digest(value['tokens'])
        inputs[key]=value;save('inputs/'+key+'.json',value)
save('freeze.json',dict(input_hashes={k:v['token_sha256'] for k,v in inputs.items()},client_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
save('method.json',dict(primary='Time from earliest request submission until the last request reports its first generated token; one output token per request.',
     input_rate='Sum of exact input token counts / primary seconds, including HTTP transfer, scheduler and prefill.',
     cache='Flush while idle before every batch. Require each reported cached prefix <=64 tokens, permitting only the tiny shared chat prefix within a concurrent batch.',
     repetitions='One excluded warmup per cell, then three measured trials. Reverse cell order for even-numbered measured trials.',
     scope='Synthetic document prefill; separate from README decode and semantic-quality tests. No profiler is active.'))
rows=[]

def run_batch(length,concurrency,trial):
    before=idle();flushed=api('/flush_cache',{});after_flush=idle()
    assert not any(word in str(flushed).lower() for word in ['cannot','failed','error']),flushed
    origin=time.perf_counter();gate=threading.Barrier(concurrency)
    def one(slot):
        key=f'document-{length}-s{slot}'
        body=dict(rid=f'{c["label"]}-{length}-c{concurrency}-t{trial}-s{slot}',input_ids=inputs[key]['tokens'],
                  sampling_params=dict(temperature=0,max_new_tokens=1,ignore_eos=True),stream=True)
        payload=json.dumps(body).encode()
        gate.wait(timeout=60);started=time.perf_counter()-origin;events=[];last=None;first=None
        req=urllib.request.Request(base+'/generate',payload,{'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=1800) as response:
                for raw in response:
                    line=raw.decode().strip()
                    if not line.startswith('data:'):continue
                    value=line[5:].strip()
                    if value=='[DONE]':break
                    last=json.loads(value);assert 'error' not in last,last
                    observed=time.perf_counter()-origin
                    events.append(dict(at_s=observed,response=last))
                    if last.get('meta_info',{}).get('completion_tokens',0)>0 and first is None:first=observed
            ended=time.perf_counter()-origin
            assert last is not None and first is not None
            meta=last['meta_info']
            assert meta['prompt_tokens']==length and meta['completion_tokens']==1,meta
            assert meta.get('num_retractions',0)==0 and 0<=meta['cached_tokens']<=64,meta
            return dict(slot=slot,input_key=key,input_sha256=inputs[key]['token_sha256'],
                        request_parameters={k:v for k,v in body.items() if k!='input_ids'},
                        start_s=started,first_token_s=first,finish_s=ended,ttft_s=first-started,
                        response=last,events=events,status='PASS')
        except BaseException as error:
            save(f'failures/{length}-c{concurrency}-t{trial}-s{slot}.json',dict(error=repr(error),events=events,last=last,input_key=key))
            raise
    with concurrent.futures.ThreadPoolExecutor(concurrency) as pool:responses=list(pool.map(one,range(concurrency)))
    loads_after=idle()
    first_start=min(x['start_s'] for x in responses)
    prefill_seconds=max(x['first_token_s'] for x in responses)-first_start
    complete_seconds=max(x['finish_s'] for x in responses)-first_start
    row=dict(context_tokens=length,concurrency=concurrency,trial=trial,warmup=trial==0,
             input_tokens=length*concurrency,output_tokens=concurrency,prefill_seconds=prefill_seconds,
             input_tokens_per_second=length*concurrency/prefill_seconds,complete_seconds=complete_seconds,
             mean_ttft_seconds=statistics.mean(x['ttft_s'] for x in responses),
             submission_spread_seconds=max(x['start_s'] for x in responses)-first_start,
             cache_flush=flushed,loads_before=before,loads_after_flush=after_flush,loads_after=loads_after,responses=responses)
    rows.append(row);save(f'rows/{length}-c{concurrency}-t{trial}.json',row)
    save('results.json',dict(rows=rows))
    print(json.dumps({k:row[k] for k in ['context_tokens','concurrency','trial','warmup','input_tokens','prefill_seconds','input_tokens_per_second','mean_ttft_seconds']}),flush=True)

try:
    for trial in range(4):
        order=list(reversed(cells)) if trial==2 else cells
        for length,concurrency in order:run_batch(length,concurrency,trial)
    save('loads-after.json',idle())
    save('completion.json',dict(status='PASS',rows=len(rows),measured_rows=sum(not r['warmup'] for r in rows),finished=datetime.datetime.now(datetime.timezone.utc).isoformat()))
except BaseException as error:
    save('failure.json',dict(error=repr(error),completed_rows=len(rows)))
    raise
