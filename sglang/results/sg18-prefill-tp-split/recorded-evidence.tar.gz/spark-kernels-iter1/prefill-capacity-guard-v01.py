"""OS-only resource guard for the eight known serving containers; no GPU telemetry."""
import concurrent.futures,datetime,json,pathlib,shlex,subprocess,sys,time
c=json.loads(pathlib.Path(sys.argv[1]).read_text());out=pathlib.Path(c['guard_dir']);out.mkdir(parents=True,exist_ok=False)
def call(rank,args):
 if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
 return subprocess.check_output(args,text=True,timeout=45)
def one(rank):
 name=c['containers'][rank]
 code='import pathlib,json,subprocess\n'+'d=json.loads(subprocess.check_output(["docker","inspect",'+repr(name)+']))[0]\n'+'m=int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))/1024**2\n'+'print(json.dumps(dict(state=d["State"],restarts=d["RestartCount"],image=d["Image"],available_gib=m)))\n'
 return dict(rank=rank,**json.loads(call(rank,['python3','-c',code])))
minimum=1000;count=0;deadline=time.monotonic()+c.get('maximum_seconds',10800)
try:
 while not (out/'stop').exists():
  with concurrent.futures.ThreadPoolExecutor(8) as p:rows=list(p.map(one,range(8)))
  minimum=min(minimum,min(r['available_gib'] for r in rows));count+=1
  with (out/'samples.jsonl').open('a') as f:f.write(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),ranks=rows))+'\n')
  assert time.monotonic()<deadline and minimum>=2 and all(r['state']['Running'] and not r['state']['OOMKilled'] and r['restarts']==0 and r['image']==c['expected_image'] for r in rows),rows
  if count==1:(out/"ready.json").write_text(json.dumps(dict(status="READY",minimum_available_gib=minimum)))
  time.sleep(3)
 (out/'completion.json').write_text(json.dumps(dict(status='PASS',samples=count,minimum_available_gib=minimum),indent=2)+'\n')
except BaseException as exc:
 (out/'failure.json').write_text(json.dumps(dict(error=repr(exc),minimum_available_gib=minimum),indent=2)+'\n')
 for rank,name in enumerate(c['containers']):
  try:call(rank,['docker','stop','-t','15',name])
  except Exception:pass
 raise
