"""Run the unchanged SG17 README benchmark and its surrounding validation."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.request

config = json.loads(Path(sys.argv[1]).read_text())
out = Path(config['out'])
out.mkdir(parents=True, exist_ok=False)
kit = Path(config['reference_kit'])
base = config['base'].rstrip('/') + '/v1'
manifest = json.loads((kit / 'reference-manifest.json').read_text())


def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


def verify_sources():
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((kit / name).read_bytes()).hexdigest() == digest, name


def idle():
    for _ in range(100):
        with urllib.request.urlopen(base + '/loads', timeout=20) as response:
            value = json.load(response)
        if all(row['num_running_reqs'] == row['num_waiting_reqs'] == 0 for row in value['loads']):
            return value
        time.sleep(.2)
    raise TimeoutError('README suite did not return to idle')


commands = []


def command(name, args, timeout):
    verify_sources()
    save('phase.json', dict(phase=name, started=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print('README_PHASE_START', name, flush=True)
    subprocess.run(args, check=True, timeout=timeout)
    commands.append(dict(phase=name, args=args, status='PASS'))
    save('commands.json', commands)
    idle()
    print('README_PHASE_PASS', name, flush=True)


try:
    verify_sources()
    save('config.json', config)
    save('reference-manifest.json', manifest)
    save('loads-before.json', idle())
    save('runtime.json', dict(node=subprocess.check_output(['node', '--version'], text=True).strip(),
         undici=json.loads((kit / 'sglang/bench/sparkdash/node_modules/undici/package.json').read_text())['version']))
    acceptance = kit / 'sglang/validation/acceptance.py'
    benchmark = kit / 'sglang/experiments/sg17-rocenante/benchmark-client.py'
    command('acceptance', ['python3', str(acceptance), '--base', base, '--out', str(out / 'acceptance')], 900)

    # Preserve the SG17 validation request bodies and simultaneous C128 gate.
    save('phase.json', dict(phase='arithmetic-c128'))
    print('README_PHASE_START arithmetic-c128', flush=True)
    gate = threading.Barrier(128)

    def arithmetic(index):
        body = dict(model='deepseek-v41-flash', messages=[dict(role='user', content=f'[SG17 arithmetic {index}] Compute {17+index} + 23. Reply with only the integer.')],
                    temperature=0, max_tokens=16, chat_template_kwargs=dict(thinking=False))
        request = urllib.request.Request(base + '/chat/completions', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
        gate.wait(timeout=30)
        with urllib.request.urlopen(request, timeout=180) as response:
            result = json.load(response)
        actual = result['choices'][0]['message']['content'].strip()
        return dict(index=index, expected=str(40+index), actual=actual, passed=actual == str(40+index), usage=result['usage'], request=body, response=result)

    with concurrent.futures.ThreadPoolExecutor(max_workers=128) as executor:
        arithmetic_rows = list(executor.map(arithmetic, range(128)))
    save('arithmetic-c128.json', arithmetic_rows)
    assert all(row['passed'] for row in arithmetic_rows)
    idle()
    print('README_PHASE_PASS arithmetic-c128 128/128', flush=True)

    command('benchmark-initial', ['python3', str(benchmark), '--out', str(out / 'benchmark-initial'), '--label', config['label'] + '-initial', '--base', base], 600)
    command('long-context', ['python3', str(kit / 'sglang/validation/long-context.py'), '--base', base,
            '--out', str(out / 'long-context'), '--tag', 'sg17-b12x-quality-v1'], 1500)
    command('acceptance-after', ['python3', str(acceptance), '--base', base, '--out', str(out / 'acceptance-after')], 900)
    command('benchmark-repeat', ['python3', str(benchmark), '--out', str(out / 'benchmark-repeat'), '--label', config['label'] + '-repeat', '--base', base], 600)
    verify_sources()
    save('loads-after.json', idle())
    save('completion.json', dict(status='PASS', finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         label=config['label'], arithmetic_correct=sum(row['passed'] for row in arithmetic_rows),
         procedure='Pinned README coding/prose wrapper before and after unchanged long-context and capability checks; no cache flush.',
         scope='Performance and capability validation for the user-authorized promotion; prior bounded quality scores remain part of the record.'))
    print('README_SUITE_COMPLETE', config['label'], flush=True)
except BaseException as error:
    save('failure.json', dict(error=repr(error), completed_commands=commands))
    raise
