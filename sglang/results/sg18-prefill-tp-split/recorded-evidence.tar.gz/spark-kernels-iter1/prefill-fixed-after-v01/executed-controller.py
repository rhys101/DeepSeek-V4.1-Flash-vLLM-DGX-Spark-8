"""Run on the benchmark host with durable file logs and the unchanged client/guard.

The launcher detaches this controller from the laptop SSH session. GPU work,
client bytes, input bytes, trial ordering, guard and measurements are unchanged.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

LAB = Path(__file__).resolve().parent
controller_source = Path(__file__).read_text()
HEAD = '/home/wavebox/deepseek-4.1-flash/spark-kernels-iter1'
CLIENT = '/home/wavebox/deepseek-4.1-flash-bench/spark-kernels-iter1'
configuration = Path(sys.argv[1]).resolve()
config = json.loads(configuration.read_text())
label = config['label']
assert label.replace('-', '').isalnum()
assert not (LAB / label).exists(), label
source = (LAB / config['script']).read_text()
config.update(out=CLIENT + '/' + label, base='http://10.10.0.221:8000',
              script_sha256=hashlib.sha256(source.encode()).hexdigest())
guard_config = dict(guard_dir=HEAD + '/' + label + '-guard', containers=config['containers'],
                    expected_image='sha256:e7681b5276525821f9be286ed3bf0f51acb5239da27f69f60fdeb57e68c05581')

def ssh(host, code, **kwargs):
    command = [sys.executable, '-'] if host == 'agenthost' else ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=3', host, 'python3 -']
    return subprocess.run(command, input=code, text=True, check=True, **kwargs)


def hardware_snapshot(phase):
    # NVML queries stay outside the benchmark-client process and all measured
    # intervals. The live guard remains OS-only.
    if not config.get('hardware_snapshots', False):
        return
    code = '''import concurrent.futures,datetime,json,pathlib,shlex,subprocess
def one(rank):
 args=['nvidia-smi','--query-gpu=uuid,name,driver_version,pstate,clocks.current.sm,clocks.current.memory,temperature.gpu,power.draw,power.limit','--format=csv']
 if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
 try:
  r=subprocess.run(args,capture_output=True,text=True,timeout=40)
  return dict(rank=rank,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 except Exception as error:return dict(rank=rank,error=repr(error))
with concurrent.futures.ThreadPoolExecutor(8) as pool:rows=list(pool.map(one,range(8)))
pathlib.Path(OUTPUT).write_text(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=PHASE,ranks=rows),indent=2)+'\\n')
'''.replace('OUTPUT', repr(guard_config['guard_dir']+'/hardware-'+phase+'.json')).replace('PHASE', repr(phase))
    ssh('wavebox@spark1', code, timeout=55)

guard_path=HEAD+'/'+label+'-guard.py'
config_path=CLIENT+'/'+label+'-config.json'
script_path=CLIENT+'/'+label+'-client.py'
ssh('wavebox@spark1', 'from pathlib import Path\np=Path('+repr(HEAD)+');p.mkdir(parents=True,exist_ok=True)\n'+
    'Path('+repr(guard_path)+').write_text('+repr((LAB/'guard.py').read_text())+')\n'+
    'Path('+repr(HEAD+'/'+label+'-guard-config.json')+').write_text('+repr(json.dumps(guard_config))+')\n', timeout=40)
ssh('agenthost', 'from pathlib import Path\np=Path('+repr(CLIENT)+');p.mkdir(parents=True,exist_ok=True)\n'+
    'assert not Path('+repr(config['out'])+').exists()\n'+
    'Path('+repr(script_path)+').write_text('+repr(source)+')\n'+
    'Path('+repr(config_path)+').write_text('+repr(json.dumps(config))+')\n', timeout=40)
with (LAB/(label+'-guard.log')).open('w') as glog:
    process=subprocess.Popen(['ssh','-o','BatchMode=yes','wavebox@spark1',
                              'python3 '+guard_path+' '+HEAD+'/'+label+'-guard-config.json'],stdout=glog,stderr=subprocess.STDOUT)
    try:
        ready='import pathlib,time\np=pathlib.Path('+repr(guard_config['guard_dir'])+')\nfor _ in range(45):\n if (p/"failure.json").exists():raise RuntimeError((p/"failure.json").read_text())\n if (p/"ready.json").exists():print((p/"ready.json").read_text());break\n time.sleep(1)\nelse:raise TimeoutError("Guard readiness")\n'
        ssh('wavebox@spark1',ready,timeout=55)
        hardware_snapshot('before')
        with (LAB/(label+'-client.log')).open('w') as log:
            timeout=config.get('timeout',7200)
            ssh('agenthost','import subprocess\nsubprocess.run(["python3",'+repr(script_path)+','+repr(config_path)+'],check=True,timeout='+str(timeout)+')\n',stdout=log,stderr=subprocess.STDOUT,timeout=timeout+60)
        hardware_snapshot('after')
    finally:
        ssh('wavebox@spark1','from pathlib import Path\nPath('+repr(guard_config['guard_dir']+'/stop')+').touch()\n',timeout=30)
        process.wait(timeout=90)
        # The client output is already local to this controller on agenthost.
        assert Path(config['out']).resolve() == (LAB/label).resolve()
        subprocess.run(['rsync','-az','wavebox@spark1:'+guard_config['guard_dir']+'/',str(LAB/(label+'-guard'))+'/'],check=True,timeout=180)
    assert process.returncode==0
assert json.loads((LAB/label/'completion.json').read_text())['status']=='PASS'
(LAB/label/'executed-client.py').write_text(source)
(LAB/label/'executed-controller.py').write_text(controller_source)
print('JOB_COMPLETE',label,flush=True)
