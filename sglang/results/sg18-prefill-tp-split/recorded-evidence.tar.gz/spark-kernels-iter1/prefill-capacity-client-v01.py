"""Cold C8 near-1M retrieval and a cached 1024-token residency proof."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import random
import sys
import threading
import time
import urllib.request

config=json.loads(Path(sys.argv[1]).read_text())
base=config['base'].rstrip('/')
out=Path(config['out']);out.mkdir(parents=True,exist_ok=False)
lock=threading.RLock();stop=threading.Event()
result=dict(status='RUNNING',phase='preparing',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            config=config,prompts=[],phases={},residency_proof=None)

def save():
    with lock:
        p=out/'result.tmp';p.write_text(json.dumps(result,indent=2)+'\n');p.replace(out/'result.json')

def write(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n')

def api(route,body=None,timeout=120):
    request=urllib.request.Request(base+route,None if body is None else json.dumps(body).encode(),{'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=timeout) as response:
        raw=response.read()
        try:return json.loads(raw)
        except json.JSONDecodeError:return raw.decode()

def idle():
    for _ in range(300):
        loads=api('/v1/loads')
        if all(r['num_running_reqs']==r['num_waiting_reqs']==0 for r in loads['loads']):return loads
        time.sleep(.2)
    raise TimeoutError('Capacity workload did not become idle')

def observe():
    consecutive_errors=0
    with (out/'loads.jsonl').open('w') as log:
        while not stop.is_set():
            row=dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),monotonic_s=time.perf_counter(),phase=result['phase'])
            try:
                row['response']=api('/v1/loads',timeout=30);consecutive_errors=0
                for load in row['response']['loads']:
                    age=time.time()-load['timestamp']
                    if (-2<=age<=10 and load['num_running_reqs']==8 and load['num_waiting_reqs']==0
                        and load['num_used_tokens']>7900000 and load['num_active_tokens']>7900000):
                        with lock:
                            if result['residency_proof'] is None:
                                result['residency_proof']=dict(row,load_snapshot_age_s=age);save()
                                print('CAPACITY_SIMULTANEOUS_RESIDENCY_PROVEN',json.dumps(load),flush=True)
            except Exception as error:
                row['error']=repr(error);consecutive_errors+=1
                # The all-rank external guard owns service safety. Missing
                # observations are retained; they never become residency proof.
                if consecutive_errors>=5:
                    with lock:result['load_observation_warning']=repr(error);save()
            log.write(json.dumps(row)+'\n');log.flush()
            stop.wait(1)

write('config.json',config);write('loads-before.json',idle())
info=api('/server_info');write('server-info.json',info)
assert (info['tp_size'],info['ep_size'],info['context_length'],info['max_total_tokens'],info['max_running_requests'],info['speculative_dspark_block_size'])==(8,4,1000000,8000000,128,5)
prompts=[]
for i in range(8):
    rng=random.Random(8161900+i)
    expected={key:str(rng.randrange(10000000,100000000)) for key in ('alpha','beta','gamma')}
    filler=997000
    prompt=(f'[capacity request={i} tag={config["tag"]}]\n'
            'Three exact records are embedded below. Ignore all filler. At the end, return only a JSON object mapping alpha, beta and gamma to their recorded eight-digit string values.\n'
            f'RECORD alpha={expected["alpha"]}\n'+' the'*(filler//2)+
            f'\nRECORD beta={expected["beta"]}\n'+' the'*(filler-filler//2)+
            f'\nRECORD gamma={expected["gamma"]}\n'
            'Return the three recorded values as a JSON object with string values. No explanation.')
    body=dict(model='deepseek-v41-flash',messages=[dict(role='user',content=prompt)],chat_template_kwargs={'thinking':False})
    tokenized=api('/v1/tokenize',body,timeout=300)
    tokens=tokenized['tokens'];assert 996900<=len(tokens)<998000,len(tokens)
    receipt=dict(index=i,seed=8161900+i,expected=expected,prompt_tokens=len(tokens),prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                 token_sha256=hashlib.sha256(json.dumps(tokens,separators=(',',':')).encode()).hexdigest(),bytes=len(prompt.encode()))
    (out/f'prompt-{i}.txt').write_text(prompt)
    result['prompts'].append(receipt);prompts.append((prompt,expected,len(tokens)));save()
assert len({r['prompt_sha256'] for r in result['prompts']})==8
write('freeze.json',dict(client_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prompts=result['prompts']))
write('loads-before-flush.json',idle());flushed=api('/flush_cache',{})
assert not any(x in str(flushed).lower() for x in ['cannot','failed','error']),flushed
write('cache-flush.json',dict(response=flushed,loads=idle()))
observer=threading.Thread(target=observe);observer.start()

def phase(name,warm):
    idle();barrier=threading.Barrier(8);origin=time.perf_counter()
    with lock:
        result['phase']=name
        result['phases'][name]=dict(status='RUNNING',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),requests=[dict(index=i,status='PENDING') for i in range(8)])
        rows=result['phases'][name]['requests'];save()
    def one(i):
        prompt,expected,token_count=prompts[i]
        body=dict(model='deepseek-v41-flash',temperature=0,max_tokens=1024 if warm else 64,
                  stream=True,stream_options={'include_usage':True},chat_template_kwargs={'thinking':False},messages=[dict(role='user',content=prompt)])
        if warm:body.update(min_tokens=1024,ignore_eos=True,stop=[])
        payload=json.dumps(body).encode();events=[];text='';usage={};finish=None;ttft=None;done=False
        barrier.wait(timeout=120);started=time.perf_counter();offset=started-origin
        with lock:rows[i].update(status='RUNNING',start_s=offset);save()
        request=urllib.request.Request(base+'/v1/chat/completions',payload,{'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(request,timeout=21600) as response:
                for raw in response:
                    line=raw.decode().strip()
                    if not line.startswith('data:'):continue
                    content=line[5:].strip()
                    if content=='[DONE]':done=True;break
                    chunk=json.loads(content);assert not chunk.get('error'),chunk
                    elapsed=time.perf_counter()-started
                    if chunk.get('usage'):usage=chunk['usage']
                    for choice in chunk.get('choices',[]):
                        piece=choice.get('delta',{}).get('content') or ''
                        if piece:
                            if ttft is None:ttft=elapsed
                            text+=piece
                        if choice.get('finish_reason') is not None:finish=choice['finish_reason']
                    events.append(dict(elapsed_s=elapsed,chunk=chunk))
                    with lock:rows[i].update(ttft_s=ttft,received_characters=len(text),last_event_s=elapsed);save()
            end=time.perf_counter();brace=text.find('{');assert brace>=0,'No JSON object'
            actual,_=json.JSONDecoder().raw_decode(text[brace:])
            assert done and finish is not None and ttft is not None,('incomplete stream',done,finish,ttft)
            assert usage['prompt_tokens']==token_count and usage['prompt_tokens']+usage['completion_tokens']<=1000000,usage
            assert usage['completion_tokens']==1024 if warm else 0<usage['completion_tokens']<=64,usage
            cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens',0)
            assert cached>=token_count-4096 if warm else 0<=cached<=64,usage
            receipt=dict(index=i,status='PASS' if actual==expected else 'FAIL',start_s=offset,end_s=end-origin,ttft_s=ttft,total_s=end-started,
                         usage=usage,actual=actual,expected=expected,retrieval_pass=actual==expected,finish_reason=finish,done_marker=done,text=text,
                         prompt_sha256=result['prompts'][i]['prompt_sha256'],request_parameters={k:v for k,v in body.items() if k!='messages'})
            write(f'{name}-r{i}.json',dict(**receipt,events=events))
            with lock:rows[i].update(receipt);save()
            print(json.dumps({k:v for k,v in receipt.items() if k!='text'}),flush=True)
            return receipt
        except BaseException as error:
            failure=dict(index=i,status='FAIL',error=repr(error),text=text,usage=usage,events=events)
            write(f'{name}-r{i}-failure.json',failure)
            with lock:rows[i].update({k:v for k,v in failure.items() if k!='events'});save()
            raise
    with concurrent.futures.ThreadPoolExecutor(8) as pool:completed=list(pool.map(one,range(8)))
    span=max(x['end_s'] for x in completed)-min(x['start_s'] for x in completed)
    with lock:
        result['phases'][name].update(status='PASS' if all(x['status']=='PASS' for x in completed) else 'FAIL',
            finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),batch_seconds=span,
            submission_spread_s=max(x['start_s'] for x in completed)-min(x['start_s'] for x in completed),
            sum_prompt_tokens=sum(x['usage']['prompt_tokens'] for x in completed),
            sum_completion_tokens=sum(x['usage']['completion_tokens'] for x in completed),
            input_tokens_per_second=sum(x['usage']['prompt_tokens'] for x in completed)/span)
        save()
    assert all(x['status']=='PASS' for x in completed),f'{name}: failed retrieval'
    print('CAPACITY_PHASE_PASS',name,flush=True)

try:
    phase('cold',False)
    phase('cached-1024',True)
    assert result['residency_proof'] is not None,'No observation of eight active requests and >7.9M used/active tokens'
    write('loads-after.json',idle())
    with lock:result.update(status='PASS',phase='complete',finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    write('completion.json',dict(status='PASS',cold_retrievals=8,cached_retrievals=8,residency_proven=True))
except BaseException as error:
    with lock:result.update(status='FAIL',phase='failed',error=repr(error));save()
    write('failure.json',dict(status='FAIL',error=repr(error)))
    raise
finally:
    stop.set();observer.join(timeout=40)
