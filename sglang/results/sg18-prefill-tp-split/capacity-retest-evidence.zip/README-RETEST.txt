Extract this archive, then run: python3 -I VERIFY-RETEST.py
This verifies packaged hashes and replays the two capacity validators in a temporary directory. No GPU or network is used. The historical failure audit is included for context; its full raw evidence is in the earlier review bundle. Live startup and service audits are recorded receipts, not recreated by offline validation.
