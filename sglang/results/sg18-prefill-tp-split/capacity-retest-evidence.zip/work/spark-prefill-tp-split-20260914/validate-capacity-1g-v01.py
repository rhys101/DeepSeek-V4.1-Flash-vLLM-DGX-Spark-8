"""Independent grading and fresh simultaneous-residency evidence audit."""
import datetime
import hashlib
import json
from pathlib import Path
import random
import re
import sys

LAB=Path(__file__).resolve().parent.parent/'spark-kernels-iter1'
label=sys.argv[1];assert label.replace('-','').isalnum()
d=LAB/label
read=lambda name:json.loads((d/name).read_text())
result=read('result.json');assert result['status']=='PASS'
assert read('completion.json')['status']=='PASS'
config=read('config.json');freeze=read('freeze.json')
assert hashlib.sha256((d/'executed-client.py').read_bytes()).hexdigest()==config['script_sha256']==freeze['client_sha256']
assert freeze['prompts']==result['prompts'] and len(freeze['prompts'])==8
assert freeze['prompts']==json.loads((LAB/'prefill-capacity-native-v01/freeze.json').read_text())['prompts']
assert set(result['phases'])=={'cold','cached-1024'}
expected=[]
for i,receipt in enumerate(result['prompts']):
 rng=random.Random(8161900+i)
 want={k:str(rng.randrange(10000000,100000000)) for k in ('alpha','beta','gamma')}
 assert receipt['index']==i and receipt['expected']==want and 996900<=receipt['prompt_tokens']<998000
 prompt=(d/f'prompt-{i}.txt').read_text()
 assert hashlib.sha256(prompt.encode()).hexdigest()==receipt['prompt_sha256']
 assert dict(re.findall(r'^RECORD (alpha|beta|gamma)=(\d{8})$',prompt,re.MULTILINE))==want
 assert f'capacity request={i} tag={config["tag"]}' in prompt
 expected.append(want)
assert len({r['prompt_sha256'] for r in result['prompts']})==8
for phase,warm in [('cold',False),('cached-1024',True)]:
 block=result['phases'][phase];assert block['status']=='PASS' and len(block['requests'])==8
 for i in range(8):
  row=read(f'{phase}-r{i}.json');assert row['status']=='PASS' and row['done_marker'] and row['finish_reason'] is not None
  assert row['prompt_sha256']==result['prompts'][i]['prompt_sha256']
  content='';usage=None
  for event in row['events']:
   chunk=event['chunk'];assert not chunk.get('error')
   if chunk.get('usage'):usage=chunk['usage']
   for choice in chunk.get('choices',[]):content+=(choice.get('delta',{}).get('content') or '')
  assert content==row['text'] and usage==row['usage']
  actual,_=json.JSONDecoder().raw_decode(content[content.index('{'):])
  assert actual==row['actual']==row['expected']==expected[i]
  assert usage['prompt_tokens']==result['prompts'][i]['prompt_tokens']
  assert usage['prompt_tokens']+usage['completion_tokens']==usage['total_tokens']<=1000000
  assert usage['completion_tokens']==1024 if warm else 0<usage['completion_tokens']<=64
  cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens',0)
  assert cached>=usage['prompt_tokens']-4096 if warm else 0<=cached<=64
  assert row['request_parameters']['temperature']==0 and row['request_parameters']['chat_template_kwargs']=={'thinking':False}
  assert row['request_parameters']['max_tokens']==(1024 if warm else 64)
  if warm:assert row['request_parameters']['min_tokens']==1024 and row['request_parameters']['ignore_eos'] and row['request_parameters']['stop']==[]
  assert row['start_s']<=row['end_s'] and 0<row['ttft_s']<=row['total_s']
  for key,value in row.items():
   if key!='events':assert block['requests'][i][key]==value,(phase,i,key)
 assert block['sum_prompt_tokens']==sum(x['usage']['prompt_tokens'] for x in block['requests'])
 assert block['sum_completion_tokens']==sum(x['usage']['completion_tokens'] for x in block['requests'])
proofs=[];samples=0
for line in (d/'loads.jsonl').read_text().splitlines():
 sample=json.loads(line);samples+=1
 received=datetime.datetime.fromisoformat(sample['observed']).timestamp()
 for load in sample.get('response',{}).get('loads',[]):
  age=received-load['timestamp']
  if (load['num_running_reqs']==8 and load['num_waiting_reqs']==0 and load['num_used_tokens']>7900000 and load['num_active_tokens']>7900000 and -2<=age<=10):
   proofs.append(dict(observed=sample['observed'],phase=sample['phase'],snapshot_age_s=age,load=load))
assert proofs,'No fresh load snapshot demonstrates all eight full contexts active together'
for name in ['loads-before.json','loads-after.json']:
 assert all(row['num_running_reqs']==row['num_waiting_reqs']==0 for row in read(name)['loads'])
guard=json.loads((LAB/(label+'-guard')/'completion.json').read_text());assert guard['status']=='PASS' and guard['minimum_available_gib']>=1
value=dict(status='PASS',label=label,cold_retrievals=8,cached_retrievals=8,
           prompt_tokens=[r['prompt_tokens'] for r in result['prompts']],cold_input_tokens=sum(r['prompt_tokens'] for r in result['prompts']),
           cold_batch_seconds=result['phases']['cold']['batch_seconds'],cold_input_tokens_per_second=result['phases']['cold']['input_tokens_per_second'],
           cached_output_tokens=result['phases']['cached-1024']['sum_completion_tokens'],load_samples=samples,
           simultaneous_residency_samples=len(proofs),first_residency_proof=proofs[0],
           maximum_used_tokens=max(p['load']['num_used_tokens'] for p in proofs),maximum_active_tokens=max(p['load']['num_active_tokens'] for p in proofs),
           minimum_available_gib=guard['minimum_available_gib'], minimum_required_available_gib=1,
           scope='Eight distinct synthetic near-1M documents, exact retrieval and simultaneous residency; no broad million-token reasoning claim.')
(d/'capacity-validation.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value,indent=2))
