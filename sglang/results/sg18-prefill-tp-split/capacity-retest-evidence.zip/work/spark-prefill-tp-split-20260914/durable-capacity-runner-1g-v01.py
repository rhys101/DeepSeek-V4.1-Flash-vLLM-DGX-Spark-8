"""Persist the exit status of a detached, file-logged benchmark controller."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

config_path = Path(sys.argv[1]).resolve()
config = json.loads(config_path.read_text())
label = config['label']
assert label.replace('-', '').isalnum()
root = config_path.parent
controller = root / 'run-capacity-durable-1g-v01.py'
status_path = root / (label + '-durable-status.json')
assert not status_path.exists()
status = dict(status='RUNNING', label=label, runner_pid=os.getpid(),
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              controller_sha256=hashlib.sha256(controller.read_bytes()).hexdigest(),
              config_sha256=hashlib.sha256(config_path.read_bytes()).hexdigest())

def save():
    temporary = status_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(status, indent=2) + '\n')
    temporary.replace(status_path)

save()
try:
    result = subprocess.run([sys.executable, str(controller), str(config_path)],
                            stdin=subprocess.DEVNULL)
    status.update(status='PASS' if result.returncode == 0 else 'FAIL',
                  controller_returncode=result.returncode)
except BaseException as error:
    status.update(status='FAIL', error=repr(error))
finally:
    status['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
sys.exit(0 if status['status'] == 'PASS' else 1)
