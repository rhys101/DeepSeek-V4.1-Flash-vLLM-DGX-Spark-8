"""Final live-service audit; no GPU workloads or container mutations."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PF = Path(__file__).resolve().parent
lab = PF.parent / 'spark-kernels-iter1'
attempt, label, readme_label = sys.argv[1:4]
assert attempt.isalnum() and all(x.replace('-', '').isalnum() for x in [label, readme_label])
destination = lab / (label + '.json')
assert not destination.exists()
assert json.loads((lab / ('components-qualified-' + attempt + '.json')).read_text())['status'] == 'PASS'
assert json.loads((lab / readme_label / 'readme-validation.json').read_text())['status'] == 'PASS'
manifest = json.loads((lab / ('candidate-tp8-' + attempt + '.json')).read_text())
source = {}
for name, digest in manifest['files'].items():
    if name.startswith('production/'):
        path = '/sgl-workspace/sglang/' + name.removeprefix('production/')
    elif name == 'configs/cluster.json':
        path = '/config/profile.json'
    else:
        path = '/opt/sglang8/' + name
    source[path] = digest
assert len(source) == len(manifest['files'])
original_source = {'/sgl-workspace/sglang/python/' + k: v['before_sha256']
                   for k, v in manifest['changed_source'].items() if v['before_sha256']}
seed = json.loads((lab / ('autotune-seed-' + attempt + '-v01.json')).read_text())
candidate_cache = {r['rank']: {v['path']: v['sha256'] for v in r['verified']} for r in seed['ranks']}
control = json.loads((lab / 'original-autotune-control-v01.json').read_text())
assert control['status'] == 'ORIGINAL_CACHE_BYTES_RESTORED'
original_cache = {r['rank']: {v['path']: v['sha256'] for v in r['verified']} for r in control['ranks']}
preserved = {}
for parent in ['readmeihw01', 'scratchfix01']:
    if parent == attempt:
        continue
    parent_manifest = json.loads((lab / ('candidate-tp8-' + parent + '.json')).read_text())
    parent_seed = json.loads((lab / ('autotune-seed-' + parent + '-v01.json')).read_text())
    parent_source = {}
    for name, digest in parent_manifest['files'].items():
        path = ('/sgl-workspace/sglang/' + name.removeprefix('production/') if name.startswith('production/')
                else '/config/profile.json' if name == 'configs/cluster.json' else '/opt/sglang8/' + name)
        parent_source[path] = digest
    preserved[parent] = dict(source=parent_source, caches={r['rank']: {v['path']: v['sha256'] for v in r['verified']} for r in parent_seed['ranks']})
staged = {rank: [] for rank in range(8)}
for path in lab.glob('stage-*.json'):
    value = json.loads(path.read_text())
    assert value['status'] == 'STAGED_STOPPED'
    for row in value['ranks']:
        if row['container'] != f'sglang8-sparkkernels-{attempt}-r{row["rank"]}':
            staged[row['rank']].append(row['container'])

code = r'''
import concurrent.futures,datetime,hashlib,io,json,pathlib,re,shlex,subprocess,tarfile,urllib.request
attempt=ATTEMPT_VALUE;label=LABEL_VALUE
source=SOURCE;original_source=ORIGINAL_SOURCE;candidate_cache=CANDIDATE_CACHE;original_cache=ORIGINAL_CACHE;staged=STAGED;environment=ENVIRONMENT;preserved=PRESERVED_VALUE
out=pathlib.Path('/home/wavebox/deepseek-4.1-flash/spark-kernels-iter1')/label;out.mkdir(exist_ok=False)
image='sha256:e7681b5276525821f9be286ed3bf0f51acb5239da27f69f60fdeb57e68c05581'
def one(rank):
 def call(args,binary=False):
  if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
  return subprocess.check_output(args,text=not binary,stderr=subprocess.PIPE,timeout=90)
 ids=call(['docker','ps','-aq']).split();assert ids
 containers=json.loads(call(['docker','inspect',*ids]));indexed={r['Name'].lstrip('/'):r for r in containers}
 candidate=f'sglang8-sparkkernels-{attempt}-r{rank}';original=f'sglang8-sg17-rocenante-r{rank}'
 d=indexed[candidate];old=indexed[original]
 assert d['Image']==old['Image']==image and d['State']['Running'] and not old['State']['Running']
 assert not d['State']['OOMKilled'] and d['RestartCount']==0
 assert all(not indexed[name]['State']['Running'] for name in staged[rank])
 live=[r['Name'].lstrip('/') for r in containers if r['State']['Running'] and r['HostConfig'].get('DeviceRequests')]
 assert live==[candidate],live
 env=dict(v.split('=',1) for v in d['Config']['Env'])
 assert all(env.get(k)==v for k,v in environment.items())
 files={**source,**candidate_cache[rank]}
 program='import hashlib,json,pathlib\nexpected='+repr(files)+'\nactual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}\nassert actual==expected\nprint(json.dumps(actual))'
 hashes=json.loads(call(['docker','exec',candidate,'python3','-S','-c',program]))
 old_hashes={}
 for path,want in {**original_source,**original_cache[rank]}.items():
  data=call(['docker','cp',original+':'+path,'-'],binary=True)
  with tarfile.open(fileobj=io.BytesIO(data)) as archive:
   members=[m for m in archive.getmembers() if m.isfile()];assert len(members)==1
   actual=hashlib.sha256(archive.extractfile(members[0]).read()).hexdigest()
  assert actual==want,(rank,path,actual,want);old_hashes[path]=actual
 preserved_rows=[]
 for parent,saved in preserved.items():
  parent_name=f'sglang8-sparkkernels-{parent}-r{rank}';p=indexed[parent_name]
  assert p['Image']==image and not p['State']['Running']
  expected={};mappings=[]
  for path,want in saved['source'].items():
   mounts=[m for m in p['Mounts'] if path==m['Destination'] or path.startswith(m['Destination'].rstrip('/')+'/')]
   assert mounts,(parent_name,path)
   mount=max(mounts,key=lambda m:len(m['Destination']))
   assert not mount['RW'],(parent_name,path,mount)
   actual_path=mount['Source']+path[len(mount['Destination']):]
   expected[actual_path]=want;mappings.append(dict(container_path=path,host_path=actual_path))
  program='import hashlib,json,pathlib\nexpected='+repr(expected)+'\nactual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}\nassert actual==expected\nprint(json.dumps(actual))'
  actual=json.loads(call(['python3','-S','-c',program]))
  cache_hashes={}
  for path,want in saved['caches'][rank].items():
   data=call(['docker','cp',parent_name+':'+path,'-'],binary=True)
   with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    members=[m for m in archive.getmembers() if m.isfile()];assert len(members)==1
    digest=hashlib.sha256(archive.extractfile(members[0]).read()).hexdigest()
   assert digest==want,(parent_name,path,digest,want);cache_hashes[path]=digest
  preserved_rows.append(dict(container=parent_name,state=p['State'],source_files=len(saved['source']),cache_files=len(saved['caches'][rank]),host_hashes=actual,cache_hashes=cache_hashes,mappings=mappings))
 memory=call(['cat','/proc/meminfo'])
 available=int(next(r.split()[1] for r in memory.splitlines() if r.startswith('MemAvailable:')))/1024**2
 assert available>=1
 # Docker writes logs to stderr as well; collect both without merging binary cp.
 args=['docker','logs','--since',d['State']['StartedAt'],candidate]
 if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
 p=subprocess.run(args,capture_output=True,text=True,timeout=90);assert p.returncode==0
 logs=p.stdout+'\n'+p.stderr;(out/f'r{rank}.log').write_text(logs)
 bad=[r for r in logs.splitlines() if re.search(r'Scheduler hit an exception|CUDA out of memory|OutOfMemoryError|illegal memory access|device-side assert|\bNaN\b|\bINVARIANT_FAILED\b',r)]
 assert not bad,(rank,bad)
 transport=[r for r in logs.splitlines() if 'NET/IB' in r];assert transport
 markers={marker:sum(marker in r for r in logs.splitlines()) for marker in ['ROCE_TP8_READY','ROCE_TP8_ROUTE','ROCE_POST_RESULT_HEALTH']}
 assert all(markers.values()),(rank,markers)
 return dict(rank=rank,candidate=candidate,state=d['State'],original=original,original_state=old['State'],stopped_candidates=sorted(staged[rank]),running_gpu_containers=live,available_gib=available,source_and_cache_hashes=hashes,original_source_and_cache_hashes=old_hashes,preserved_baselines=preserved_rows,environment={k:env[k] for k in environment},logs_sha256=hashlib.sha256(logs.encode()).hexdigest(),transport_lines=transport[:16],health_markers=markers)
with concurrent.futures.ThreadPoolExecutor(8) as pool:ranks=list(pool.map(one,range(8)))
with urllib.request.urlopen('http://127.0.0.1:8000/v1/loads',timeout=15) as response:loads=json.load(response)
assert all(r['num_running_reqs']==r['num_waiting_reqs']==0 for r in loads['loads'])
with urllib.request.urlopen('http://127.0.0.1:8000/server_info',timeout=15) as response:info=json.load(response)
result=dict(ranks=ranks,loads=loads,server_info=info,observed=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'read-only-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
for key, value in [('ATTEMPT_VALUE', attempt), ('LABEL_VALUE', label), ('PRESERVED_VALUE', preserved), ('ORIGINAL_SOURCE', original_source), ('CANDIDATE_CACHE', candidate_cache), ('ORIGINAL_CACHE', original_cache), ('SOURCE', source), ('STAGED', staged), ('ENVIRONMENT', manifest['environment'])]:
    code = code.replace(key, repr(value))
result = json.loads(subprocess.check_output(['ssh', '-o', 'BatchMode=yes', 'wavebox@spark1', 'python3 -'], input=code, text=True, timeout=180))
baseline_info = json.loads((lab / 'baseline-evaluation-v01/server-info.json').read_text())
active_info = result['server_info']
assert active_info.keys() == baseline_info.keys()
separate = {'startup_time', 'internal_states'}
assert {k:v for k,v in active_info.items() if k not in separate} == {k:v for k,v in baseline_info.items() if k not in separate}
assert len(active_info['internal_states']) == len(baseline_info['internal_states'])
state_separate = {'startup_time', 'memory_usage', 'avg_spec_accept_length', 'last_gen_throughput'}
for active_state, baseline_state in zip(active_info['internal_states'], baseline_info['internal_states']):
    assert {k:v for k,v in active_state.items() if k not in state_separate} == {k:v for k,v in baseline_state.items() if k not in state_separate}
    for key in ['token_capacity', 'token_capacity_swa']:
        assert active_state['memory_usage'][key] == baseline_state['memory_usage'][key]
result['runtime_contract'] = 'PASS: serving settings and logical token capacities match the original; startup, memory use and generation statistics remain observations.'
process_code = """
import json,pathlib
hits=[]
for path in pathlib.Path('/proc').glob('[0-9]*/cmdline'):
 try:args=[a.decode(errors='replace') for a in path.read_bytes().split(b'\\0') if a]
 except (OSError,PermissionError):continue
 if any(arg.startswith(('/home/wavebox/deepseek-4.1-flash/spark-kernels-iter1/','/home/wavebox/deepseek-4.1-flash-bench/spark-kernels-iter1/')) and arg.endswith('.py') for arg in args):hits.append(dict(pid=int(path.parent.name),argv=args))
print(json.dumps(hits))
"""
jobs = {host: json.loads(subprocess.check_output(['ssh', '-o', 'BatchMode=yes', host, 'python3 -'], input=process_code, text=True, timeout=30)) for host in ['wavebox@spark1', 'agenthost']}
processes = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True).splitlines()
controllers = [p.name for p in lab.glob('run-*.py')]
controllers += [p.name for p in PF.glob('run-*.py')]
jobs['local'] = [r.strip() for r in processes if any(prefix + name in r for name in controllers for prefix in ['spark-kernels-iter1/', 'spark-prefill-tp-split-20260914/'])]
assert all(not v for v in jobs.values()), jobs
result.update(status='PASS', active_experiment_jobs=jobs, controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), scope=f'{attempt} running and idle on all eight ranks; all {len(source)} staged files and candidate caches match; original service and cache bytes preserved stopped; prior candidates stopped; no experiment jobs remain.')
destination.write_text(json.dumps(result, indent=2) + '\n')
subprocess.run(['rsync', '-az', 'wavebox@spark1:/home/wavebox/deepseek-4.1-flash/spark-kernels-iter1/'+label+'/', str(lab / label) + '/'], check=True, timeout=120)
print(json.dumps(dict(status=result['status'], observed=result['observed'], minimum_available_gib=min(r['available_gib'] for r in result['ranks']), active_experiment_jobs=jobs)))
