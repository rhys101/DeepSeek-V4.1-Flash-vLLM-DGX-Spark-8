"""Package the completed reboot retest; never mutate historical measurements."""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

PF = Path(__file__).resolve().parent
ROOT = PF.parent.parent
LAB = PF.parent / 'spark-kernels-iter1'
OUT = ROOT / 'outputs'
LABEL = 'prefill-capacity-native-reboot-1g-v01'
AUDIT = 'prefill-reboot-final-candidate-audit-v01'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
validation = read(LAB / LABEL / 'capacity-validation.json')
guard = read(PF / (LABEL + '-raw-guard-validation-v01.json'))
audit = read(LAB / (AUDIT + '.json'))
result = read(LAB / LABEL / 'result.json')
terminal = read(LAB / (LABEL + '-durable-status.json'))
preflight = read(PF / (LABEL + '-reboot-preflight-v01.json'))
prepared = read(PF / 'capacity-reboot-retest-preparation-v01.json')
launch = read(PF / (LABEL + '-durable-launch.json'))
prior = read(PF / 'prefill-capacity-failure-audit-v01.json')
prior_decision = read(PF / 'prefill-final-decision-v01.json')
assert validation['status'] == audit['status'] == result['status'] == terminal['status'] == 'PASS'
assert guard['status'] == 'PASS_RAW_GUARD_SAMPLES'
assert preflight['status'] == 'PASS_REBOOT_RETEST_PREFLIGHT'
assert all(not jobs for jobs in audit['active_experiment_jobs'].values())
assert all(r['candidate'] == f'sglang8-sparkkernels-prefillnative01-r{r["rank"]}' for r in audit['ranks'])
assert guard['minimum_required_available_gib'] == validation['minimum_required_available_gib'] == 1
assert prior['minimum_available_gib'] < 2 and prior['completed_cold_retrievals'] == 0
for relative, digest in prepared['prepared_files'].items():
    assert sha(PF.parent / relative) == digest, relative
for relative, digest in preflight['evidence_sha256'].items():
    assert sha(PF.parent / relative) == digest, relative
source_by_name = {Path(k).name: v for k, v in prepared['prepared_files'].items()}
for name, digest in launch['files'].items():
    if name == 'prefill-capacity-client-v01.py':
        assert digest == sha(LAB / LABEL / 'executed-client.py') == prepared['capacity_client_sha256']
    elif name.endswith('-durable-input.json'):
        assert digest == sha(LAB / name)
    else:
        assert source_by_name[name] == digest
assert sha(LAB / LABEL / 'executed-controller.py') == sha(PF / 'run-capacity-durable-1g-v01.py')

cold, cached = (result['phases'][k] for k in ['cold', 'cached-1024'])
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
evidence_paths = [LAB / LABEL / 'capacity-validation.json', PF / (LABEL + '-raw-guard-validation-v01.json'),
                  LAB / (AUDIT + '.json'), LAB / (LABEL + '-durable-status.json'),
                  PF / (LABEL + '-reboot-preflight-v01.json'), PF / 'spark1-reboot-observed-v01.json',
                  PF / 'prefill-capacity-failure-audit-v01.json', PF / 'prefill-final-decision-v01.json']
decision = dict(status='PASS_REBOOT_CAPACITY_RETEST', recorded=now, label=LABEL,
                candidate='prefillnative01', active_service='prefillnative01', active_ranks=8,
                tested_minimum_os_available_gib=1, observed_minimum_available_gib=guard['minimum_available_gib'],
                spark1_minimum_available_gib=guard['minimum_by_rank_gib'][0],
                cold_retrievals=8, cached_retrievals=8, cached_output_tokens=8192,
                simultaneous_residency_samples=validation['simultaneous_residency_samples'],
                maximum_simultaneous_used_tokens=validation['maximum_used_tokens'],
                final_audit_status=audit['status'], final_audit_observed=audit['observed'],
                final_audit_minimum_available_gib=min(r['available_gib'] for r in audit['ranks']),
                active_experiment_jobs=audit['active_experiment_jobs'],
                baseline_preserved_stopped=True, publication='No repository publication performed for this retest.',
                prior_capacity_failure_preserved=True,
                evidence_sha256={str(p.relative_to(ROOT)): sha(p) for p in evidence_paths})
decision_path = PF / 'prefill-capacity-retest-decision-v01.json'
assert not decision_path.exists()
decision_path.write_text(json.dumps(decision, indent=2) + '\n')
export = dict(status=decision['status'], decision=decision, capacity_validation=validation,
              raw_guard_validation=guard,
              phases={phase: {k: v for k, v in block.items() if k != 'requests'} for phase, block in result['phases'].items()},
              requests={phase: [{k: row[k] for k in ['index', 'status', 'prompt_sha256', 'ttft_s', 'total_s', 'usage', 'actual', 'expected', 'finish_reason']} for row in block['requests']] for phase, block in result['phases'].items()},
              prompt_receipts=result['prompts'], prior_capacity_failure=prior,
              earlier_confirmation_time_reductions_percent=prior_decision['primary_confirmation_time_reductions_percent'],
              scope='Same eight distinct synthetic 997,100-token prompts after the user rebooted Spark1. Exact retrieval and simultaneous residency are established for this run; this is not a broad million-token reasoning evaluation or proof of the earlier memory failure cause.')
json_path = OUT / 'prefill-capacity-retest-20260914.json'
report_path = OUT / 'prefill-capacity-retest-20260914.md'
zip_path = OUT / 'prefill-capacity-retest-evidence-20260914.zip'
assert all(not p.exists() for p in [json_path, report_path, zip_path])
json_path.write_text(json.dumps(export, indent=2) + '\n')
memory_rows = '\n'.join(f'| Spark{i+1} / rank {i} | {value:.3f} |' for i, value in enumerate(guard['minimum_by_rank_gib']))
report = f'''# Prefill capacity retest — 14 September 2026

**PASS after the Spark1 reboot.** The unchanged native prefill candidate completed the same eight near-million-token documents with the requested **1 GiB OS-available memory stop threshold**. Independent grading passed, and the candidate remains running and idle on all eight nodes.

| Check | Verified result |
|---|---|
| Distinct input documents | 8 × 997,100 tokens; 7,976,800 input tokens total |
| Cold retrieval | 8/8 exact answers; 20 output tokens each |
| Cached retrieval | 8/8 exact answers; exactly 1,024 output tokens each |
| Simultaneous residency | {validation['simultaneous_residency_samples']} fresh records with 8 running, 0 waiting, and >7.9M used and active tokens |
| Maximum slots used with all eight active | {validation['maximum_used_tokens']:,} |
| Minimum sampled OS-available memory | {guard['minimum_available_gib']:.3f} GiB, on Spark7 |
| Spark1 minimum | {guard['minimum_by_rank_gib'][0]:.3f} GiB |
| Worker continuity | Same processes and image across all {guard['samples']:,} samples; no recorded OOM or restart |

The cold phase ran from 21:37:08 to 22:52:09 UTC: **{cold['batch_seconds']/60:.2f} minutes**, or {cold['input_tokens_per_second']:,.1f} input tokens/s for the batch. The cached phase completed in **{cached['batch_seconds']:.2f} seconds**, producing 8,192 tokens total. These are capacity-run timings; cached prompt tokens are not a cold-prefill speed measurement.

Spark1's new boot was verified at 21:24:14 UTC. Before launch, all 261 staged source/configuration files and both expert caches on each rank matched the previously qualified candidate. The 500 serving-setting checks passed, and the service had no active requests or previous prefill. All eight prompt receipts and prompt bytes match the prior attempt exactly. The client and serving implementation were unchanged. The threshold changed from 2 to 1 GiB; the controller also received the documented cleanup-wait and evidence-retention fixes.

The independent validators reconstructed every response from its saved streaming events, checked all expected retrieval values and token counts, compared the frozen prompts, and verified fresh simultaneous-residency records. Every cached request reported 996,864 cached prompt tokens. The guard contains {guard['rank_observations']:,} rank observations, sampled about every {guard['mean_sample_interval_seconds']:.2f} seconds, with a maximum interval of {guard['maximum_sample_interval_seconds']:.2f} seconds. The memory minimum describes these recorded samples.

| Node | Minimum OS-available GiB |
|---|---:|
{memory_rows}

The prior run remains recorded as a failure: Spark1 reached {prior['minimum_available_gib']:.3f} GiB and triggered its then-required 2 GiB stop before any retrieval completed. This repeat stayed above 2 GiB in all recorded samples as well, so it did not need to use the additional headroom allowed by the new 1 GiB limit. The successful repeat after reboot does not by itself establish the cause of the earlier memory drop. Five OS-only Spark1 process-memory snapshots are included for diagnosis; they do not provide full CUDA allocation attribution.

The final audit at {audit['observed']} verified unchanged source, caches and serving settings; healthy transport and worker logs; zero running or waiting requests; preserved stopped baselines; and no experiment jobs remaining. The lowest available memory during that audit was {decision['final_audit_minimum_available_gib']:.3f} GiB. **`prefillnative01` is the active service on all eight nodes.** The earlier 21–28% long-prefill timing improvements remain separate historical measurements. No repository publication was performed for this retest.

This establishes exact retrieval and simultaneous residency for these eight synthetic documents. It does not establish broad million-token reasoning quality.

The accompanying JSON contains the measured results and decision. The evidence ZIP contains all prompts, streaming records, load samples, raw guard samples, executed client/controller sources, pinned guard and validator sources, startup and final audits, worker logs, and the original prompt-freeze reference. Its `VERIFY-RETEST.py` checks hashes and replays both independent validators locally without network or GPU access. The earlier [evaluation](prefill-evaluation-20260914.md) and [source/review bundle](prefill-review-draft-20260914.zip) are preserved as historical artifacts.
'''
report_path.write_text(report)

paths = set()
def add(path):
    assert path.exists(), path
    if path.is_dir():
        paths.update(p for p in path.rglob('*') if p.is_file())
    else:
        paths.add(path)
for p in [LAB / LABEL, LAB / (LABEL + '-guard'), LAB / 'startup-nativerebootstart01',
          LAB / AUDIT, LAB / (AUDIT + '.json'), PF / (LABEL + '-terminal-live-v01'),
          LAB / 'prefill-capacity-native-v01/freeze.json', decision_path, json_path, report_path,
          OUT / 'prefill-capacity-retest-plan-20260914.md']:
    add(p)
for suffix in ['-durable-status.json', '-durable-launch.json', '-durable-input.json', '-durable-controller.log', '-client.log', '-guard.log']:
    add(LAB / (LABEL + suffix))
for pattern in [LABEL + '*.json', LABEL + '*.jsonl', LABEL + '*collection.log', 'nativerebootstart01*.json']:
    for p in PF.glob(pattern):
        add(p)
for relative in set(prepared['prepared_files']) | set(preflight['evidence_sha256']):
    add(PF.parent / relative)
for name in ['prepare-capacity-reboot-retest-v01.py', 'assert-capacity-reboot-preflight-v01.py',
             'observe-spark1-reboot-v01.py', 'capacity-retest-guard-validation-v01.json',
             'observe-capacity-head-memory-v01.py', 'collect-capacity-retest-terminal-v01.py',
             'manage-durable-job-v01.py', 'prefill-capacity-failure-audit-v01.json',
             'prefill-final-decision-v01.json', 'package-capacity-retest-v01.py', 'verify-capacity-retest-package-v01.py']:
    add(PF / name)
paths.add(LAB / 'prefill-capacity-client-v01.py')
assert sha(LAB / 'prefill-capacity-client-v01.py') == prepared['capacity_client_sha256']
files = {str(p.relative_to(ROOT)): p.read_bytes() for p in sorted(paths)}
files['VERIFY-RETEST.py'] = (PF / 'verify-capacity-retest-package-v01.py').read_bytes()
files['README-RETEST.txt'] = b'Extract this archive, then run: python3 -I VERIFY-RETEST.py\nThis verifies packaged hashes and replays the two capacity validators in a temporary directory. No GPU or network is used. The historical failure audit is included for context; its full raw evidence is in the earlier review bundle. Live startup and service audits are recorded receipts, not recreated by offline validation.\n'
manifest = dict(status='PASS_REBOOT_CAPACITY_RETEST', label=LABEL,
                files={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in files.items()})
files['RETEST-MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(zip_path) as archive:
    assert set(archive.namelist()) == set(files)
    assert all(archive.read(name) == data for name, data in files.items())
receipt = dict(status='PASS_RETEST_PACKAGE_READBACK', recorded=now, files=len(files),
               uncompressed_bytes=sum(map(len, files.values())), zip_bytes=zip_path.stat().st_size,
               zip_sha256=sha(zip_path), decision_sha256=sha(decision_path),
               report_sha256=sha(report_path), json_sha256=sha(json_path))
(PF / 'prefill-capacity-retest-deliverable-v01.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
