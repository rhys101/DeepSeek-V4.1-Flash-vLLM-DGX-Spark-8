"""Read OS memory and only the known head serving process tree; no GPU APIs."""
import json
from pathlib import Path
import subprocess
import sys

PF = Path(__file__).resolve().parent
label, phase = sys.argv[1:3]
assert label == 'prefill-capacity-native-reboot-1g-v01'
assert phase.replace('-', '').isalnum()
code = r'''
import datetime,json,pathlib,subprocess
container='sglang8-sparkkernels-prefillnative01-r0'
d=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
mem={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
system={key:mem[key] for key in ['MemTotal','MemFree','MemAvailable','Buffers','Cached','SwapCached','Active(anon)','Inactive(anon)','Active(file)','Inactive(file)','Unevictable','Mlocked','SwapTotal','SwapFree','AnonPages','Mapped','Shmem','Slab','SReclaimable','SUnreclaim','PageTables'] if key in mem}
pending=[d['State']['Pid']] if d['State']['Running'] else [];seen=set();rows=[]
while pending:
 pid=pending.pop()
 if pid in seen:continue
 seen.add(pid);root=pathlib.Path('/proc')/str(pid)
 try:
  status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (root/'status').read_text().splitlines() if ':' in line}
  children=[int(value) for value in (root/'task'/str(pid)/'children').read_text().split()]
  pending.extend(children)
  row=dict(pid=pid,children=children,status={key:status[key] for key in ['Name','PPid','VmSize','VmRSS','RssAnon','RssFile','RssShmem','VmSwap','Threads'] if key in status})
  try:
   rollup={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (root/'smaps_rollup').read_text().splitlines() if ':' in line}
   row['smaps_rollup']={key:rollup[key] for key in ['Rss','Pss','Pss_Anon','Pss_File','Pss_Shmem','Private_Clean','Private_Dirty','Shared_Clean','Shared_Dirty','Anonymous','Locked'] if key in rollup}
  except (OSError,PermissionError) as error:row['smaps_unavailable']=type(error).__name__
  rows.append(row)
 except (OSError,PermissionError) as error:rows.append(dict(pid=pid,error=type(error).__name__))
print(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=PHASE_VALUE,container=container,state=d['State'],os_memory=system,processes=rows,
                     scope='OS counters and the serving container process tree only. No NVML or GPU profiler. RSS/PSS are not a complete CUDA allocation attribution.')))
'''.replace('PHASE_VALUE',repr(phase))
value = json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','wavebox@spark1','python3 -'],input=code,text=True,timeout=40))
with (PF / (label + '-head-memory.jsonl')).open('a') as output:
    output.write(json.dumps(value)+'\n')
def rss(row):
    return int(row.get('status',{}).get('VmRSS','0 kB').split()[0])
print(json.dumps(dict(observed=value['observed'],phase=phase,os_available_gib=int(value['os_memory']['MemAvailable'].split()[0])/1024**2,
                     serving_processes=len(value['processes']),largest_rss_processes=[dict(pid=row['pid'],status=row.get('status',{})) for row in sorted(value['processes'],key=rss,reverse=True)[:8]]),indent=2))
