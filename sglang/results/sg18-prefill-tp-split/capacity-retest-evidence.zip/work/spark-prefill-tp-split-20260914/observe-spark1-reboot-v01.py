"""Read boot identity and known serving-container states; never mutate services."""
import datetime
import json
from pathlib import Path
import subprocess

PF = Path(__file__).resolve().parent
code = r'''
import concurrent.futures,datetime,json,pathlib,shlex,subprocess
def one(rank):
 def call(args):
  if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes','-o','ConnectTimeout=10',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
  return subprocess.check_output(args,text=True,timeout=40)
 names=[f'sglang8-sparkkernels-{attempt}-r{rank}' for attempt in ['scratchfix01','prefillnative01','readmeihw01']]
 values=json.loads(call(['docker','inspect',*names]))
 return dict(rank=rank,containers=[dict(name=row['Name'].lstrip('/'),state=row['State'],restarts=row['RestartCount'],image=row['Image']) for row in values])
boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
boot_epoch=int(next(line.split()[1] for line in pathlib.Path('/proc/stat').read_text().splitlines() if line.startswith('btime ')))
with concurrent.futures.ThreadPoolExecutor(8) as pool:ranks=list(pool.map(one,range(8)))
print(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),boot_id=boot_id,boot_time=datetime.datetime.fromtimestamp(boot_epoch,datetime.timezone.utc).isoformat(),uptime_seconds=float(pathlib.Path('/proc/uptime').read_text().split()[0]),ranks=ranks)))
'''
result = json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','wavebox@spark1','python3 -'],input=code,text=True,timeout=65))
handoff = json.loads((PF.parent / 'spark-kernels-iter1/prefill-final-baseline-audit-v01.json').read_text())
result['reboot_after_previous_handoff'] = datetime.datetime.fromisoformat(result['boot_time']) > datetime.datetime.fromisoformat(handoff['observed'])
if result['reboot_after_previous_handoff']:
    destination = PF / 'spark1-reboot-observed-v01.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(observed=result['observed'],boot_time=result['boot_time'],uptime_seconds=result['uptime_seconds'],reboot_after_previous_handoff=result['reboot_after_previous_handoff'],
                     ranks=[dict(rank=row['rank'],containers=[dict(name=c['name'],running=c['state']['Running'],oom=c['state']['OOMKilled']) for c in row['containers']]) for row in result['ranks']]),indent=2))
