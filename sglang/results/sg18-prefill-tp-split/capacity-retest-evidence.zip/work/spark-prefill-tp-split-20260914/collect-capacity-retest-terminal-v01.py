"""Preserve terminal reboot-retest worker logs and guard files without mutation."""
import json
from pathlib import Path
import subprocess

PF = Path(__file__).resolve().parent
LABEL = 'prefill-capacity-native-reboot-1g-v01'
OUT = PF / (LABEL + '-terminal-live-v01')
LAB = PF.parent / 'spark-kernels-iter1'
assert json.loads((LAB / (LABEL + '-durable-status.json')).read_text())['status'] in ('PASS', 'FAIL')
assert not OUT.exists()
code = r'''
import concurrent.futures,datetime,json,pathlib,shlex,subprocess
root=pathlib.Path('/home/wavebox/deepseek-4.1-flash/spark-kernels-iter1')
guard=root/'prefill-capacity-native-reboot-1g-v01-guard'
def one(rank):
 name=f'sglang8-sparkkernels-prefillnative01-r{rank}'
 def call(args):
  if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
  return subprocess.run(args,capture_output=True,text=True,timeout=45)
 inspect=call(['docker','inspect',name]);assert inspect.returncode==0
 d=json.loads(inspect.stdout)[0]
 logs=call(['docker','logs','--since',d['State']['StartedAt'],name])
 assert logs.returncode==0
 return dict(rank=rank,container=name,state=d['State'],restarts=d['RestartCount'],image=d['Image'],logs=logs.stdout+'\n'+logs.stderr)
with concurrent.futures.ThreadPoolExecutor(8) as pool:ranks=list(pool.map(one,range(8)))
files={p.name:p.read_text() for p in guard.iterdir() if p.is_file()}
print(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),ranks=ranks,guard_files=files)))
'''
value = json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','wavebox@spark1','python3 -'], input=code,text=True,timeout=90))
OUT.mkdir()
for row in value['ranks']:
    (OUT / f'r{row["rank"]}.log').write_text(row.pop('logs'))
guard = OUT / 'guard'
guard.mkdir()
for name, content in value.pop('guard_files').items():
    assert '/' not in name
    (guard / name).write_text(content)
(OUT / 'states.json').write_text(json.dumps(value,indent=2)+'\n')
failure = json.loads((guard/'failure.json').read_text()) if (guard/'failure.json').exists() else None
print(json.dumps(dict(observed=value['observed'],states=[{k:r[k] for k in ['rank','state','restarts']} for r in value['ranks']],guard_failure=failure),indent=2))
