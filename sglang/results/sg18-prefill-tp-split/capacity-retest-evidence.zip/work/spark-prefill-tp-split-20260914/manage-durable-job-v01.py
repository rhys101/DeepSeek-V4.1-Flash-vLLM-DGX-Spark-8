"""Read durable job receipts, or collect a terminal run without changing it."""
import json
from pathlib import Path
import subprocess
import sys

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
action, label = sys.argv[1:3]
assert action in ('status', 'collect') and label.replace('-', '').isalnum()
launch = json.loads((PF / (label + '-durable-launch.json')).read_text())
assert launch['status'] == 'LAUNCHED'
root = '/home/wavebox/deepseek-4.1-flash-bench/spark-kernels-iter1'
code = r'''
import datetime,json,pathlib
root=pathlib.Path(ROOT_VALUE);label=LABEL_VALUE
result={'observed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label}
for suffix in ['-durable-status.json','-durable-launch.json']:
 p=root/(label+suffix)
 if p.exists():result[suffix]=json.loads(p.read_text())
for name in ['completion.json','failure.json']:
 p=root/label/name
 if p.exists():result[name]=json.loads(p.read_text())
p=root/label/'results.json'
if p.exists():
 value=json.loads(p.read_text());rows=value.get('rows',[])
 result['completed_batches']=len(rows)
 result['measured_batches']=sum(not row['warmup'] for row in rows)
 result['timing_rows']=[{key:row[key] for key in ['context_tokens','concurrency','trial','warmup','prefill_seconds']} for row in rows]
p=root/(label+'-durable-controller.log')
if p.exists():result['controller_log_tail']=p.read_text()[-3000:]
p=root/(label+'-guard')/'completion.json'
if p.exists():result['guard_completion']=json.loads(p.read_text())
print(json.dumps(result))
'''.replace('ROOT_VALUE', repr(root)).replace('LABEL_VALUE', repr(label))
result = json.loads(subprocess.check_output(
    ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'agenthost', 'python3 -'],
    input=code, text=True, timeout=35))
if action == 'collect':
    assert result['-durable-status.json']['status'] in ('PASS', 'FAIL'), result
    for directory in [label, label + '-guard']:
        destination = LAB / directory
        assert not destination.exists(), destination
        subprocess.run(['rsync', '-az', 'agenthost:' + root + '/' + directory + '/',
                        str(destination) + '/'], check=True, timeout=240)
    for suffix in ['-durable-status.json', '-durable-launch.json', '-durable-input.json',
                   '-durable-controller.log', '-client.log', '-guard.log']:
        subprocess.run(['rsync', '-az', 'agenthost:' + root + '/' + label + suffix,
                        str(LAB / (label + suffix))], check=True, timeout=40)
    (PF / (label + '-durable-collected.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
