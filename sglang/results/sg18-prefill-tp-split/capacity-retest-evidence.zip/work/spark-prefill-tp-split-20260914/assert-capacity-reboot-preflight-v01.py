"""Verify the new Spark1 boot and fresh qualified candidate before capacity."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
LABEL = 'prefill-capacity-native-reboot-1g-v01'
TRIAL = 'nativerebootstart01'
DIR = LAB / ('startup-' + TRIAL)
evidence = {}


def read(path):
    raw = path.read_bytes()
    evidence[str(path.relative_to(PF.parent))] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


reboot = read(PF / 'spark1-reboot-observed-v01.json')
assert reboot['reboot_after_previous_handoff']
qualification = read(LAB / 'startup-qualified-prefillnative01.json')
assert qualification['status'] == 'READY' and qualification['trial'] == TRIAL
contract = read(DIR / 'runtime-contract.json')
assert contract['status'] == 'PASS' and contract['identical_top_level_settings'] == 500 and contract['checked_source_ranks'] == 8
cache = read(DIR / 'autotune-control.json')
assert cache['status'] == 'CACHE_FILES_VERIFIED_DISPATCH_REQUIRED'
completion = read(DIR / 'completion.json')
assert completion['status'] == 'READY' and completion['minimum_available_gib'] >= 1
source_hashes = read(DIR / 'source-hashes.json')
assert len(source_hashes) == 8
startup_info = read(DIR / 'server-info.json')
manifest = read(LAB / 'candidate-tp8-prefillnative01.json')
components = read(LAB / 'components-qualified-prefillnative01.json')
assert components['status'] == 'PASS' and components['receipt']['candidate_files'] == manifest['files']
seed = read(LAB / 'autotune-seed-prefillnative01-v01.json')
source_files = {}
for name, sha in manifest['files'].items():
    path = ('/sgl-workspace/sglang/' + name.removeprefix('production/') if name.startswith('production/')
            else '/config/profile.json' if name == 'configs/cluster.json' else '/opt/sglang8/' + name)
    source_files[path] = sha
cache_files = {row['rank']:{item['path']:item['sha256'] for item in row['verified']} for row in seed['ranks']}
assert read(LAB / 'prefill-profile4k-native-v01-dispatch-validation.json')['status'] == 'PASS'
preparation = read(PF / 'capacity-reboot-retest-preparation-v01.json')
assert preparation['minimum_os_available_gib'] == 1 and preparation['label'] == LABEL
for name, sha in preparation['prepared_files'].items():
    assert hashlib.sha256((PF.parent / name).read_bytes()).hexdigest() == sha, name
config = read(LAB / (LABEL + '.json'))
assert config['tag'] == 'prefill-tp8-20260914-v01'
head_state = completion['ranks'][0]['state']
assert head_state['StartedAt'].endswith('Z')
# Docker records nanoseconds; the local Python parser accepts microseconds.
# Whole UTC seconds suffice to establish that startup followed this reboot.
started = datetime.datetime.fromisoformat(head_state['StartedAt'][:19] + '+00:00')
assert started > datetime.datetime.fromisoformat(reboot['boot_time'])
code = r'''
import concurrent.futures,datetime,json,pathlib,shlex,subprocess,urllib.request
boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==BOOT_ID_VALUE
source_files=SOURCE_FILES_VALUE;cache_files=CACHE_FILES_VALUE
def one(rank):
 name=f'sglang8-sparkkernels-prefillnative01-r{rank}'
 expected={**source_files,**cache_files[rank]}
 program='import hashlib,json,pathlib\nexpected='+repr(expected)+'\nactual={name:hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() for name in expected}\nassert actual==expected\nprint(json.dumps(actual))'
 args=['docker','exec',name,'python3','-S','-c',program]
 if rank:args=['ssh','-b','192.168.100.11','-o','BatchMode=yes',f'wavebox@192.168.100.{11+rank}',shlex.join(args)]
 hashes=json.loads(subprocess.check_output(args,text=True,timeout=40))
 return dict(rank=rank,source_files=len(source_files),expert_cache_files=len(cache_files[rank]),verified_sha256=hashes)
with concurrent.futures.ThreadPoolExecutor(8) as pool:ranks=list(pool.map(one,range(8)))
d=json.loads(subprocess.check_output(['docker','inspect','sglang8-sparkkernels-prefillnative01-r0'],text=True))[0]
assert d['State']['Running'] and not d['State']['OOMKilled'] and d['RestartCount']==0
assert d['State']['Pid']==PID_VALUE and d['State']['StartedAt']==STARTED_VALUE
with urllib.request.urlopen('http://127.0.0.1:8000/server_info',timeout=15) as response:info=json.load(response)
assert info['startup_time']==STARTUP_VALUE
with urllib.request.urlopen('http://127.0.0.1:8000/v1/loads',timeout=15) as response:loads=json.load(response)
assert loads['loads']
for row in loads['loads']:
 for key in ['num_running_reqs','num_waiting_reqs','num_waiting_uncached_tokens','num_used_tokens','num_active_tokens','total_prefill_uncached_tokens']:
  assert row[key]==0,(key,row[key])
print(json.dumps(dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),boot_id=boot,state=d['State'],startup_time=info['startup_time'],loads=loads,ranks=ranks)))
'''
for name, value in [('BOOT_ID_VALUE',reboot['boot_id']),('PID_VALUE',head_state['Pid']),('STARTED_VALUE',head_state['StartedAt']),('STARTUP_VALUE',startup_info['startup_time']),('SOURCE_FILES_VALUE',source_files),('CACHE_FILES_VALUE',cache_files)]:
    code = code.replace(name,repr(value))
observed = json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','wavebox@spark1','python3 -'],input=code,text=True,timeout=45))
value = dict(status='PASS_REBOOT_RETEST_PREFLIGHT',label=LABEL,trial=TRIAL,minimum_os_available_gib=1,
             boot_time=reboot['boot_time'],observed=observed,evidence_sha256=evidence,
             scope='Verified Spark1 reboot, exact qualified candidate source/caches and serving settings, and a fresh idle process with zero recorded prior prefill. Run only the unchanged capacity client next.')
destination = PF / (LABEL + '-reboot-preflight-v01.json')
assert not destination.exists()
destination.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(status=value['status'],label=LABEL,boot_time=reboot['boot_time'],observed=observed['observed'],minimum_os_available_gib=1)))
