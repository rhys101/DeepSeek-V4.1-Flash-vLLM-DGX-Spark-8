"""Stage and detach a bounded benchmark on the existing benchmark host."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
config_path = Path(sys.argv[1]).resolve()
config = json.loads(config_path.read_text())
label = config['label']

# The first capacity run failed. This is a separate, explicitly authorized
# repeat after a verified reboot and fresh qualified candidate startup.
authorization = json.loads((PF / 'capacity-reboot-retest-preparation-v01.json').read_text())
assert authorization['minimum_os_available_gib'] == 1
assert label == authorization['label'] == 'prefill-capacity-native-reboot-1g-v01'
preflight = json.loads((PF / (label + '-reboot-preflight-v01.json')).read_text())
assert preflight['status'] == 'PASS_REBOOT_RETEST_PREFLIGHT'
assert preflight['label'] == label and preflight['minimum_os_available_gib'] == 1
assert config['tag'] == 'prefill-tp8-20260914-v01'
for name, expected in authorization['prepared_files'].items():
    assert hashlib.sha256((PF.parent / name).read_bytes()).hexdigest() == expected, name

# This workload remains conditional on the completed confirmation decision.
decision = json.loads((PF / 'prefill-confirmation-decision-v01.json').read_text())
assert decision['status'] == 'PASS_PRECAPACITY' and decision['candidate'] == 'prefillnative01'
for name, expected in decision['evidence_sha256'].items():
    assert hashlib.sha256((PF / name).read_bytes()).hexdigest() == expected, name
assert config['script'] == 'prefill-capacity-client-v01.py' and config['timeout'] == 21000
assert config['containers'] == [f'sglang8-sparkkernels-prefillnative01-r{i}' for i in range(8)]
assert label.replace('-', '').isalnum()
assert not (LAB / label).exists()
receipt = PF / (label + '-durable-launch.json')
assert not receipt.exists()
files = {
    'run-capacity-durable-1g-v01.py': (PF / 'run-capacity-durable-1g-v01.py').read_text(),
    'durable-capacity-runner-1g-v01.py': (PF / 'durable-capacity-runner-1g-v01.py').read_text(),
    'prefill-capacity-guard-1g-v01.py': (LAB / 'prefill-capacity-guard-1g-v01.py').read_text(),
    config['script']: (LAB / config['script']).read_text(),
    label + '-durable-input.json': json.dumps(config, indent=2) + '\n',
}
for name, content in files.items():
    if name.endswith('.py'):
        ast.parse(content)
code = r'''
import datetime,hashlib,json,pathlib,subprocess,sys,urllib.request
root=pathlib.Path('/home/wavebox/deepseek-4.1-flash-bench/spark-kernels-iter1')
files=FILES_VALUE;label=LABEL_VALUE
assert not (root/label).exists()
for suffix in ['-durable-status.json','-durable-launch.json','-durable-controller.log']:
 assert not (root/(label+suffix)).exists()
with urllib.request.urlopen('http://10.10.0.221:8000/v1/loads',timeout=15) as response:loads=json.load(response)
assert all(all(x[key]==0 for key in ['num_running_reqs','num_waiting_reqs','num_waiting_uncached_tokens','num_used_tokens','num_active_tokens','total_prefill_uncached_tokens']) for x in loads['loads']),loads
for name,content in files.items():
 p=root/name
 if p.exists():assert p.read_text()==content,name
for name,content in files.items():
 p=root/name
 if not p.exists():p.write_text(content)
with (root/(label+'-durable-controller.log')).open('xb') as log:
 process=subprocess.Popen([sys.executable,str(root/'durable-capacity-runner-1g-v01.py'),str(root/(label+'-durable-input.json'))],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=root)
result=dict(status='LAUNCHED',label=label,pid=process.pid,observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={name:hashlib.sha256(content.encode()).hexdigest() for name,content in files.items()},loads_before=loads)
(root/(label+'-durable-launch.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'''.replace('FILES_VALUE', repr(files)).replace('LABEL_VALUE', repr(label))
result = json.loads(subprocess.check_output(
    ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'agenthost', 'python3 -'],
    input=code, text=True, timeout=45))
result['launcher_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
