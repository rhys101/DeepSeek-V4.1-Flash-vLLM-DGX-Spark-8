"""Prepare the user-authorized one-GiB repeat without contacting the cluster."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

PF = Path(__file__).resolve().parent
LAB = PF.parent / 'spark-kernels-iter1'
LABEL = 'prefill-capacity-native-reboot-1g-v01'


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior_guard = (LAB / 'prefill-capacity-guard-v01.py').read_text()
guard = replace_once(prior_guard, 'minimum>=2', 'minimum>=1')
assert ast.dump(ast.parse(guard.replace('minimum>=1', 'minimum>=2'))) == ast.dump(ast.parse(prior_guard))
controller = (PF / 'run-capacity-durable-v01.py').read_text()
controller = replace_once(controller, 'keeps the two-GiB stop rule', 'uses the user-authorized one-GiB stop rule')
controller = controller.replace('prefill-capacity-guard-v01.py', 'prefill-capacity-guard-1g-v01.py')
controller = replace_once(controller, 'process.wait(timeout=90)', 'process.wait(timeout=420)')
old_cleanup = "        subprocess.run(['rsync','-az','wavebox@spark1:'+guard_config['guard_dir']+'/',str(LAB/(label+'-guard'))+'/'],check=True,timeout=180)\n"
new_cleanup = old_cleanup + "        (LAB/label/'executed-client.py').write_text(source)\n        (LAB/label/'executed-controller.py').write_text(controller_source)\n"
controller = replace_once(controller, old_cleanup, new_cleanup)
runner = (PF / 'durable-capacity-runner-v01.py').read_text().replace('run-capacity-durable-v01.py', 'run-capacity-durable-1g-v01.py')
launcher = (PF / 'launch-durable-capacity-v01.py').read_text()
launcher = launcher.replace('run-capacity-durable-v01.py', 'run-capacity-durable-1g-v01.py')
launcher = launcher.replace('durable-capacity-runner-v01.py', 'durable-capacity-runner-1g-v01.py')
launcher = launcher.replace('prefill-capacity-guard-v01.py', 'prefill-capacity-guard-1g-v01.py')
new_gate = '''
# The first capacity run failed. This is a separate, explicitly authorized
# repeat after a verified reboot and fresh qualified candidate startup.
authorization = json.loads((PF / 'capacity-reboot-retest-preparation-v01.json').read_text())
assert authorization['minimum_os_available_gib'] == 1
assert label == authorization['label'] == 'prefill-capacity-native-reboot-1g-v01'
preflight = json.loads((PF / (label + '-reboot-preflight-v01.json')).read_text())
assert preflight['status'] == 'PASS_REBOOT_RETEST_PREFLIGHT'
assert preflight['label'] == label and preflight['minimum_os_available_gib'] == 1
assert config['tag'] == 'prefill-tp8-20260914-v01'
for name, expected in authorization['prepared_files'].items():
    assert hashlib.sha256((PF.parent / name).read_bytes()).hexdigest() == expected, name
'''
launcher = replace_once(launcher, "label = config['label']\n", "label = config['label']\n" + new_gate)
launcher = replace_once(launcher,
    "assert all(x['num_running_reqs']==x['num_waiting_reqs']==x['num_waiting_uncached_tokens']==0 for x in loads['loads']),loads",
    "assert all(all(x[key]==0 for key in ['num_running_reqs','num_waiting_reqs','num_waiting_uncached_tokens','num_used_tokens','num_active_tokens','total_prefill_uncached_tokens']) for x in loads['loads']),loads")
validator = (PF / 'validate-capacity-v01.py').read_text()
validator = replace_once(validator, "guard['minimum_available_gib']>=2", "guard['minimum_available_gib']>=1")
validator = replace_once(validator, "assert freeze['prompts']==result['prompts'] and len(freeze['prompts'])==8",
    "assert freeze['prompts']==result['prompts'] and len(freeze['prompts'])==8\nassert freeze['prompts']==json.loads((LAB/'prefill-capacity-native-v01/freeze.json').read_text())['prompts']")
validator = replace_once(validator, "minimum_available_gib=guard['minimum_available_gib'],", "minimum_available_gib=guard['minimum_available_gib'], minimum_required_available_gib=1,")
raw_validator = (PF / 'validate-guard-samples-v01.py').read_text()
raw_validator = replace_once(raw_validator, "row['available_gib'] >= 2", "row['available_gib'] >= 1")
raw_validator = replace_once(raw_validator, "minimum_by_rank_gib=minimum,", "minimum_by_rank_gib=minimum, minimum_required_available_gib=1,")
raw_validator = replace_once(raw_validator, 'at least two GiB OS-available', 'at least one GiB OS-available under the user-authorized repeat threshold')
audit = (PF / 'audit-prefill-handoff-v01.py').read_text()
audit = replace_once(audit, 'assert available>=2', 'assert available>=1')
files = {
    LAB / 'prefill-capacity-guard-1g-v01.py': guard,
    PF / 'run-capacity-durable-1g-v01.py': controller,
    PF / 'durable-capacity-runner-1g-v01.py': runner,
    PF / 'launch-durable-capacity-1g-v01.py': launcher,
    PF / 'validate-capacity-1g-v01.py': validator,
    PF / 'validate-guard-samples-1g-v01.py': raw_validator,
    PF / 'audit-prefill-handoff-1g-v01.py': audit,
}
for path, source in files.items():
    assert not path.exists(), path
    ast.parse(source)
config = json.loads((LAB / 'prefill-capacity-native-v01.json').read_text())
assert sha(LAB / config['script']) == '2c0d99812ea8ccf0904b22abdf532f265f1dc8eb68f484e6d7d942fc9c893298'
config['label'] = LABEL
config_path = LAB / (LABEL + '.json')
assert not config_path.exists()
for path, source in files.items():
    path.write_text(source)
config_path.write_text(json.dumps(config, indent=2) + '\n')
receipt = dict(status='PREPARED_WAITING_FOR_USER_REBOOT', recorded=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               label=LABEL, candidate='prefillnative01', minimum_os_available_gib=1,
               user_instruction='let me reboot spark1, then we can try again. put thelimit at 1 Gb and retest',
               prior_failed_run='prefill-capacity-native-v01', prior_minimum_os_available_gib=2,
               capacity_client_sha256=sha(LAB / config['script']),
               original_guard_sha256=sha(LAB / 'prefill-capacity-guard-v01.py'),
               prepared_files={str(path.relative_to(PF.parent)):sha(path) for path in [*files, config_path]},
               guard_change='Only the memory comparison changes from 2 to 1 GiB; all rank/image/OOM/restart checks and the six-hour bound are retained.',
               controller_changes='Use the separate 1-GiB guard. Allow 420 seconds for the existing sequential shutdown, and archive executed source in the finalizer even when the client fails.',
               input_policy='Unchanged client, original tag and seeds, identical eight 997,100-token prompt hashes required, same cold64 and cached1024 output protocol.',
               pending='Wait for Spark1 reboot, stop preserved baseline workers, qualify a fresh candidate start, and record reboot/idle preflight before launch.',
               scope='A separate repeat with an explicitly changed memory acceptance threshold. The original two-GiB failure and prior final decision remain immutable historical records.')
destination = PF / 'capacity-reboot-retest-preparation-v01.json'
assert not destination.exists()
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
