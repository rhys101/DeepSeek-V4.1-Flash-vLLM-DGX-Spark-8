"""Validate an extracted retest bundle with the Python standard library only."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'RETEST-MANIFEST.json').read_text())
label = manifest['label']
assert label == 'prefill-capacity-native-reboot-1g-v01'
for name, receipt in manifest['files'].items():
    path = root / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert path.is_file() and not path.is_symlink(), name
    data = path.read_bytes()
    assert len(data) == receipt['bytes'] and hashlib.sha256(data).hexdigest() == receipt['sha256'], name
with tempfile.TemporaryDirectory(prefix='prefill-retest-verify-') as tmp:
    destination = Path(tmp)
    shutil.copytree(root / 'work', destination / 'work')
    pf = destination / 'work/spark-prefill-tp-split-20260914'
    lab = destination / 'work/spark-kernels-iter1'
    capacity_path = lab / label / 'capacity-validation.json'
    guard_path = pf / (label + '-raw-guard-validation-v01.json')
    expected_capacity = json.loads(capacity_path.read_text())
    expected_guard = json.loads(guard_path.read_text())
    capacity_path.unlink()
    guard_path.unlink()
    for script in ['validate-capacity-1g-v01.py', 'validate-guard-samples-1g-v01.py']:
        subprocess.run([sys.executable, '-I', str(pf / script), label], check=True, capture_output=True, text=True)
    assert json.loads(capacity_path.read_text()) == expected_capacity
    assert json.loads(guard_path.read_text()) == expected_guard
    decision = json.loads((pf / 'prefill-capacity-retest-decision-v01.json').read_text())
    for relative, digest in decision['evidence_sha256'].items():
        assert hashlib.sha256((destination / relative).read_bytes()).hexdigest() == digest
    prepared = json.loads((pf / 'capacity-reboot-retest-preparation-v01.json').read_text())
    preflight = json.loads((pf / (label + '-reboot-preflight-v01.json')).read_text())
    for relative, digest in {**prepared['prepared_files'], **preflight['evidence_sha256']}.items():
        assert hashlib.sha256((destination / 'work' / relative).read_bytes()).hexdigest() == digest
print(json.dumps(dict(status='PASS_OFFLINE_RETEST_VERIFICATION', packaged_files=len(manifest['files']),
                      independent_validators_replayed=2, cold_retrievals=8, cached_retrievals=8,
                      cached_output_tokens=8192, simultaneous_residency_samples=expected_capacity['simultaneous_residency_samples'],
                      minimum_available_gib=expected_guard['minimum_available_gib']), indent=2))
