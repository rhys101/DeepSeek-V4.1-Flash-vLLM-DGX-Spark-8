# Prefill capacity retest — 14 September 2026

**PASS after the Spark1 reboot.** The unchanged native prefill candidate completed the same eight near-million-token documents with the requested **1 GiB OS-available memory stop threshold**. Independent grading passed, and the candidate remains running and idle on all eight nodes.

| Check | Verified result |
|---|---|
| Distinct input documents | 8 × 997,100 tokens; 7,976,800 input tokens total |
| Cold retrieval | 8/8 exact answers; 20 output tokens each |
| Cached retrieval | 8/8 exact answers; exactly 1,024 output tokens each |
| Simultaneous residency | 30 fresh records with 8 running, 0 waiting, and >7.9M used and active tokens |
| Maximum slots used with all eight active | 7,983,872 |
| Minimum sampled OS-available memory | 3.555 GiB, on Spark7 |
| Spark1 minimum | 4.446 GiB |
| Worker continuity | Same processes and image across all 1,299 samples; no recorded OOM or restart |

The cold phase ran from 21:37:08 to 22:52:09 UTC: **75.01 minutes**, or 1,772.3 input tokens/s for the batch. The cached phase completed in **60.32 seconds**, producing 8,192 tokens total. These are capacity-run timings; cached prompt tokens are not a cold-prefill speed measurement.

Spark1's new boot was verified at 21:24:14 UTC. Before launch, all 261 staged source/configuration files and both expert caches on each rank matched the previously qualified candidate. The 500 serving-setting checks passed, and the service had no active requests or previous prefill. All eight prompt receipts and prompt bytes match the prior attempt exactly. The client and serving implementation were unchanged. The threshold changed from 2 to 1 GiB; the controller also received the documented cleanup-wait and evidence-retention fixes.

The independent validators reconstructed every response from its saved streaming events, checked all expected retrieval values and token counts, compared the frozen prompts, and verified fresh simultaneous-residency records. Every cached request reported 996,864 cached prompt tokens. The guard contains 10,392 rank observations, sampled about every 3.53 seconds, with a maximum interval of 4.07 seconds. The memory minimum describes these recorded samples.

| Node | Minimum OS-available GiB |
|---|---:|
| Spark1 / rank 0 | 4.446 |
| Spark2 / rank 1 | 5.531 |
| Spark3 / rank 2 | 3.824 |
| Spark4 / rank 3 | 4.939 |
| Spark5 / rank 4 | 7.023 |
| Spark6 / rank 5 | 5.015 |
| Spark7 / rank 6 | 3.555 |
| Spark8 / rank 7 | 4.919 |

The prior run remains recorded as a failure: Spark1 reached 1.953 GiB and triggered its then-required 2 GiB stop before any retrieval completed. This repeat stayed above 2 GiB in all recorded samples as well, so it did not need to use the additional headroom allowed by the new 1 GiB limit. The successful repeat after reboot does not by itself establish the cause of the earlier memory drop. Five OS-only Spark1 process-memory snapshots are included for diagnosis; they do not provide full CUDA allocation attribution.

The final audit at 2026-09-14T22:54:37.533316+00:00 verified unchanged source, caches and serving settings; healthy transport and worker logs; zero running or waiting requests; preserved stopped baselines; and no experiment jobs remaining. The lowest available memory during that audit was 10.517 GiB. **`prefillnative01` is the active service on all eight nodes.** The earlier 21–28% long-prefill timing improvements remain separate historical measurements. No repository publication was performed for this retest.

This establishes exact retrieval and simultaneous residency for these eight synthetic documents. It does not establish broad million-token reasoning quality.

The accompanying JSON contains the measured results and decision. The evidence ZIP contains all prompts, streaming records, load samples, raw guard samples, executed client/controller sources, pinned guard and validator sources, startup and final audits, worker logs, and the original prompt-freeze reference. Its `VERIFY-RETEST.py` checks hashes and replays both independent validators locally without network or GPU access. The earlier [evaluation](prefill-evaluation-20260914.md) and [source/review bundle](prefill-review-draft-20260914.zip) are preserved as historical artifacts.
