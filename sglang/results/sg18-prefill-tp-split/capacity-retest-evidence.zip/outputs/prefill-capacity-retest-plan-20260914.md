# Capacity repeat after Spark1 reboot

**Requested change:** repeat the native prefill candidate's eight near-1M
capacity test after the user's Spark1 reboot, with a **1 GiB OS-available stop
threshold** on every node. The prior 2 GiB failure remains recorded separately.

After the reboot, stop and preserve the old baseline workers, start the exact
qualified candidate on all eight ranks, and recheck source hashes, expert
caches, serving settings and an idle fresh process before testing.

Use the unchanged client, prompt tag and eight seeds: eight distinct 997,100-token
inputs, the same cold retrieval pass, then the same 1,024-token cached pass.
Require exact retrievals and fresh server records showing eight running requests,
zero waiting requests and more than 7.9M used and active tokens simultaneously.
Retain the six-hour test bound and all worker/image/OOM/restart checks.

The controller will allow enough time to collect the existing sequential
shutdown and will save its executed source on a failed run. This changes
cleanup recording, not the workload or serving implementation.

Independently validate the saved requests, prompt hashes, residency records and
all-rank memory samples against the new 1 GiB threshold. Finish with a source,
cache, health and idle audit; preserve the baseline for rollback.

**Current state:** the repeat launched at **21:36 UTC** as
`prefill-capacity-native-reboot-1g-v01`. Spark1's new boot at 21:24 UTC was
verified; candidate startup, all 500 settings, all 261 source/configuration
files and both expert caches on every rank passed. Preflight and launch found
zero prior prefill and no active or waiting requests. Startup's minimum
OS-available memory was 7.48 GiB. The retest uses the requested 1 GiB threshold.

A few separate OS-only snapshots of Spark1's serving process tree will be
retained for memory diagnosis. They use no GPU profiler or NVML calls. The
original client, requests and measurements remain unchanged.
